local defaults = {
 bufferSeconds=300, beforeSeconds=30, afterSeconds=15, width=1920, height=1080,
 fps=30, bitrateMbps=8, bufferLimitGB=15, minimumFreeGB=2,
 systemAudio=true, microphone=false, hardwareEncoder=true, cursor=true,
 myPvpKills=true, partyPvpKills=false, nearbyPlayerDeaths=false, myDeath=true,
 myNpcKills=false, interrupts=false, spellCasts=false, spellIds="", lootIds="", lootChatLogging=false,
 quickOne=30, quickTwo=60, quickThree=120, showBar=true, revision="0",
 pvpKills=0, pvpDeaths=0, pvpLog={}, pvpLogSerial=0, pvpLogSort="Newest"
}
local db, panel, bar, signal, status, sequence = nil, nil, nil, nil, nil, 0
local pvpReadyAt = math.huge
local lastPersonalKillAt = -100
local editors = {}
local function say(s) print("|cffff3557Rektflix:|r "..s) end
local function safeText(x) return not (issecretvalue and issecretvalue(x)) and type(x)=="string" end
local function button(parent,text,x,y,w,fn)
 local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate"); b:SetSize(w or 150,24); b:SetPoint("TOPLEFT",x,y); b:SetText(text); b:SetScript("OnClick",fn); return b
end
local function iconButton(parent,kind,x,fn,tip)
 local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate");b:SetSize(34,24);b:SetPoint("TOPLEFT",x,-36);b:SetScript("OnClick",fn);b.rfAction=kind
 if kind=="settings" then local t=b:CreateTexture(nil,"ARTWORK");t:SetSize(16,16);t:SetPoint("CENTER");t:SetTexture("Interface/Buttons/UI-OptionsButton")
 else local t=b:CreateFontString(nil,"OVERLAY","GameFontNormalLarge");t:SetPoint("CENTER",0,kind=="record" and 1 or 0);t:SetText(kind=="record" and "|cffff3557●|r" or "|cffffffff■|r") end
 b:SetScript("OnEnter",function(self)if GameTooltip then GameTooltip:SetOwner(self,"ANCHOR_TOP");GameTooltip:SetText(tip);GameTooltip:Show()end end)
 b:SetScript("OnLeave",function()if GameTooltip then GameTooltip:Hide()end end);return b
end
local function label(parent,text,x,y,width,font)
 local t=parent:CreateFontString(nil,"OVERLAY",font or "GameFontHighlight"); t:SetPoint("TOPLEFT",x,y); t:SetWidth(width or 600); t:SetJustifyH("LEFT");t:SetText(text);return t
end
local function backdrop(f)
 f:SetBackdrop({bgFile="Interface/Tooltips/UI-Tooltip-Background",edgeFile="Interface/Tooltips/UI-Tooltip-Border",tile=true,tileSize=16,edgeSize=12,insets={left=3,right=3,top=3,bottom=3}})
 f:SetBackdropColor(0.055,0.06,0.08,0.97);f:SetBackdropBorderColor(0.8,0.15,0.25,1)
end
local function makeSignal()
 signal=CreateFrame("Frame",nil,UIParent);signal:SetFrameStrata("TOOLTIP");signal:SetSize(112,8)
 signal:SetScale(1/UIParent:GetEffectiveScale());signal:SetPoint("TOPLEFT",UIParent,"TOPLEFT",8,-8)
 signal.cells={};for i=1,28 do local t=signal:CreateTexture(nil,"OVERLAY");t:SetSize(4,8);t:SetPoint("TOPLEFT",(i-1)*4,0);signal.cells[i]=t end
end
local function send(code,arg)
 if not signal then return end
 sequence=(sequence+1)%256;arg=math.max(0,math.min(255,arg or 0))
 local packed=code+sequence*16+arg*4096
 local checksum=(code+sequence+arg)%16
 packed=packed+checksum*1048576
 signal.cells[1]:SetColorTexture(1,0,0.5,1);signal.cells[2]:SetColorTexture(0,1,0.5,1)
 for i=0,23 do local bit=math.floor(packed/2^i)%2;signal.cells[i+3]:SetColorTexture(bit,bit,bit,1) end
 signal.cells[27]:SetColorTexture(0,0,0,1);signal.cells[28]:SetColorTexture(1,1,1,1)
 local sentSequence=sequence
 signal:Show();C_Timer.After(2,function() if signal and sequence==sentSequence then signal:Hide() end end)
 say("Request sent. Check the Windows app for confirmation.")
end
local function guidLabel(guid)
 if not safeText(guid)then return "Unknown"end
 local own=UnitGUID and UnitGUID("player");if safeText(own)and guid==own then return "You"end
 return guid
end
local function addPvpLog(kind,other,source)
 db.pvpLog=type(db.pvpLog)=="table"and db.pvpLog or {};db.pvpLogSerial=(tonumber(db.pvpLogSerial)or 0)+1
 if kind=="KILL"then db.pvpKills=(tonumber(db.pvpKills)or 0)+1 elseif kind=="DEATH"then db.pvpDeaths=(tonumber(db.pvpDeaths)or 0)+1 end
 db.pvpLog[#db.pvpLog+1]={n=db.pvpLogSerial,time=GetServerTime(),kind=kind,other=other or "Unknown",source=source or "Forever event"}
 while #db.pvpLog>2000 do table.remove(db.pvpLog,1)end
end
local function sortedPvpLog()
 local rows={};for _,row in ipairs(db.pvpLog or {})do rows[#rows+1]=row end
 local mode=db.pvpLogSort or "Newest"
 table.sort(rows,function(a,b)
  if mode=="Oldest"then return (a.n or 0)<(b.n or 0)end
  if mode=="Kills first"and a.kind~=b.kind then return a.kind=="KILL"end
  if mode=="Deaths first"and a.kind~=b.kind then return a.kind=="DEATH"end
  return (a.n or 0)>(b.n or 0)
 end);return rows
end
local function exportPvpLog()
 local lines={"Rektflix PvP Log","Lifetime kills\t"..tostring(db.pvpKills or 0),"Lifetime deaths\t"..tostring(db.pvpDeaths or 0),"Number\tTime\tType\tOther player/GUID\tSource"}
 for _,row in ipairs(sortedPvpLog())do lines[#lines+1]=table.concat({row.n or "",date and date("%Y-%m-%d %H:%M:%S",row.time or 0)or tostring(row.time or 0),row.kind or "",row.other or "Unknown",row.source or ""},"\t")end
 local f=CreateFrame("Frame",nil,UIParent,"BackdropTemplate");f:SetSize(720,430);f:SetPoint("CENTER");f:SetFrameStrata("TOOLTIP");backdrop(f);label(f,"COPYABLE REKTFLIX PVP LOG",18,-16,620,"GameFontNormalLarge")
 local e=CreateFrame("EditBox",nil,f,"InputBoxTemplate");e:SetPoint("TOPLEFT",18,-52);e:SetSize(682,320);e:SetMultiLine(true);e:SetAutoFocus(true);e:SetMaxLetters(999999);e:SetText(table.concat(lines,"\n"));e:HighlightText();e:SetFocus()
 button(f,"Close",550,-385,150,function()f:Hide()end)
end
local helpText = [[REKTFLIX — 'N KILL.

GETTING STARTED
Open the Rektflix Windows app, then launch WoW. Its installer places this addon in the selected Classic folder. A newly installed addon requires restarting WoW if the game was already running. Use /rf or /rektflix for these settings; /rf bar toggles the compact control bar.

WHAT RECORDS?
The Windows app continuously records the WoW window while armed. Buffer length is how much recent footage it retains. Old unmarked footage expires; saved clips are never automatically deleted. The buffer is written to disk, not just RAM. Recording stops when you quit the app; minimizing its window can leave it running in the tray.

SAVE / RECORD / STOP
The three Save buttons preserve your chosen number of recent seconds immediately, with no extra after-time. Record starts a continuous saved clip from now. Stop ends that clip; it does not turn off the rolling buffer. Disarm in the Windows app stops all capture. A short coloured signal strip appears at the upper-left of WoW when you press a button. Keep WoW in the foreground and visible for the Windows app to read it. This sends requests only: this addon cannot know whether the Windows recorder succeeded. Use the app for confirmation. No keypresses or game inputs are automated.

TIMING
Before / after settings apply to automatic combat triggers. Overlapping automatic triggers merge into one clip. Save durations cannot exceed the buffer. Keyframe alignment can include a little extra footage. During startup, only footage already captured is available. Log writes can be delayed by WoW, so external log triggers may occur after the event; a longer before-window helps.

VIDEO AND AUDIO
Resolution preserves the original aspect ratio with letterboxing. Frame rate is the requested recording rate, not a promise that your PC or WoW will render that many frames. Bitrate is the video quality control: more Mbps means larger files. Hardware encoding uses the GPU where available; the app reports failures and can retry with software. System audio captures the default playback device, including Discord or music. Microphone is off by default. Changing audio devices during capture may require stopping and rearming.

BITRATE / QUALITY GUIDE
These are practical H.264 starting ranges for WoW. Use the lower end for smaller friend-sharing files and the upper end for busy battlegrounds, lots of spell effects, fast camera movement, or cleaner text. Results vary by encoder and scene.

720p 30 FPS: 4-6 Mbps. Good compact quality; 6 is cleaner in combat.
720p 60 FPS: 6-9 Mbps. Smooth and shareable; below 6 may block during motion.
1080p 30 FPS: 7-10 Mbps. 8 Mbps is the recommended balanced default.
1080p 60 FPS: 10-16 Mbps. Use 12 for good quality or 16 for busy PvP.
1440p 30 FPS: 12-18 Mbps. Use about 16 for clean UI text and effects.
1440p 60 FPS: 18-28 Mbps. Use 22-24 as a strong starting point.
4K 30 FPS: 25-40 Mbps. Use at least 30 for detailed combat.
4K 60 FPS: 40-50 Mbps. 50 is this app's maximum; very demanding.

Quality shorthand: 2-4 Mbps is economy quality and may show blur or blocks; 6-10 Mbps is good for 720p/1080p30 sharing; 12-20 Mbps is high quality for 1080p60 or 1440p; 25-50 Mbps is large-file high-resolution capture. Raising bitrate cannot restore detail missing from the selected resolution or FPS, and extremely high bitrate may look little better after a sharing site recompresses the clip.

Storage estimate: every 1 Mbps uses about 0.45 GB per hour, plus a small amount for audio. Examples: 8 Mbps is about 3.6 GB/hour or 18 GB for five hours; 12 Mbps is about 5.4 GB/hour; 20 Mbps is about 9 GB/hour; 50 Mbps is about 22.5 GB/hour. Set the buffer-space limit above the expected rolling-buffer size and leave the configured free-space reserve available.

APPLYING SETTINGS
Apply & Reload UI writes settings to SavedVariables. The Windows app reads the newest saved ReKtflix settings from the selected installation and restarts capture if needed. Reload cannot run in combat. Apply after combat. Windows controls can also change recording settings immediately; these changes are not automatically written back into a running addon. Applying this page later replaces the corresponding Windows settings. Clip destination is chosen in the Windows app.

TRIGGERS AND FOREVER
Forever has two trigger paths. PARTY_KILL can signal an actual killing blow when the event's identities are readable. PLAYER_PVP_KILLS_CHANGED also catches honorable PvP kill credit, so the default PvP option favors catching a moment over requiring a perfect killing-blow classification. UNIT_DIED and PLAYER_DEAD supplement nearby-death and own-death detection. Forever can mark unit identities secret; Rektflix never bypasses that restriction. Combat logging is also enabled, and the Windows app parses the on-disk log as a fallback and for richer optional triggers. It must show fresh events before you rely on automatic detection. Nearby means events Blizzard sends in your event/log range, not the whole zone or world. Exact Forever realm behavior still requires live validation.

WATCHED ITEMS
Optional item IDs match item links seen in the chat log. This is a 'watched item seen in chat' trigger, NOT proof that the item just dropped: linked items can also match. Enabling this also enables WoW chat logging, which stores chat on your computer. Combat logging and chat logs belong to WoW and can grow separately from Rektflix's buffer. Rektflix does not delete WoW logs.

PVP LOG
The PvP Log tab keeps a lifetime kill-credit high score plus up to 2,000 numbered kill/death rows in SavedVariables. Sort by newest, oldest, kills first or deaths first. Export opens a copyable tab-separated log; Clear requires two clicks. /rf log opens it directly. Forever does not always reveal who dealt the killing blow when PLAYER_DEAD fires, so those deaths are honestly labeled Unknown.

RECOVERY AND STORAGE
Completed MP4 fragments are flushed to disk. If capture or Windows crashes, the app recovers available footage on the next recording start. Power loss may still lose recent fragments or corrupt storage; no software can guarantee survival of unflushed device caches. A UPS improves protection. A pending clip may be shorter if the game or app closes before its after-time. Disk reserve or buffer quota exhaustion stops capture with an error instead of deleting saved clips. Keep enough space for your buffer plus pending clips and exports.

TROUBLESHOOTING
No clips: check that the Windows app is armed, WoW is selected, and combat-log events are arriving. No signal: keep WoW in the foreground, ensure the upper-left strip is unobstructed, and use the Windows buttons as a fallback. Black/stalled capture: restore WoW if minimized, use windowed/borderless mode, and restart capture. Capture may be limited on old graphics drivers. Open diagnostics from the Windows app. Clips are fragmented MP4 files; use a modern video player. Never treat the addon bar as proof of recording: only the Windows app observes the recorder.
]]
local function readEditors()
 for _,e in ipairs(editors) do
  if e.kind=="bool" then db[e.key]=e.widget:GetChecked() and true or false
  elseif e.kind=="minutes" then local n=tonumber(e.widget:GetText());if not n then say("Enter minutes for "..e.key);return false end;db[e.key]=math.floor(math.max(e.min,math.min(e.max,n))*60)
  elseif e.kind=="number" then local n=tonumber(e.widget:GetText());if not n then say("Enter a number for "..e.key);return false end;db[e.key]=math.floor(math.max(e.min,math.min(e.max,n)))
  else db[e.key]=e.widget:GetText():gsub("[^0-9, ]","") end
 end
 db.beforeSeconds=math.min(db.beforeSeconds,db.bufferSeconds)
 for _,key in ipairs({"quickOne","quickTwo","quickThree"})do db[key]=math.min(db[key],db.bufferSeconds) end
 return true
end
local function buildPanel(tab)
 if panel then panel:Hide();panel:SetParent(nil) end
 editors={};panel=CreateFrame("Frame","RektflixSettings"..tostring(GetTime()):gsub("%.",""),UIParent,"BackdropTemplate");panel:SetSize(760,620);panel:SetPoint("CENTER");panel:SetFrameStrata("DIALOG");backdrop(panel)
 panel:SetMovable(true);panel:EnableMouse(true);panel:RegisterForDrag("LeftButton");panel:SetScript("OnDragStart",panel.StartMoving);panel:SetScript("OnDragStop",panel.StopMovingOrSizing)
 label(panel,"REKTFLIX",20,-18,600,"GameFontNormalLarge");label(panel,"'n kill.",20,-43,680)
 button(panel,"X",718,-12,26,function()panel:Hide()end)
 local tabs={"Recording","Triggers","Storage","PvP Log","Help"}
 for i,name in ipairs(tabs)do button(panel,name,20+(i-1)*140,-72,130,function()if readEditors() then buildPanel(name)end end)end
 local scroll=CreateFrame("ScrollFrame",nil,panel,"UIPanelScrollFrameTemplate");scroll:SetPoint("TOPLEFT",20,-110);scroll:SetPoint("BOTTOMRIGHT",-40,64)
 local content=CreateFrame("Frame",nil,scroll);content:SetSize(680,1000);scroll:SetScrollChild(content);local y=-4
 local function note(text) local t=label(content,text,0,y,665);local h=t:GetStringHeight();y=y-h-15 end
 local function number(key,title,min,max,tip)
  label(content,title,0,y,470);local e=CreateFrame("EditBox",nil,content,"InputBoxTemplate");e:SetSize(130,24);e:SetPoint("TOPLEFT",510,y+3);e:SetAutoFocus(false);e:SetMaxLetters(8);e:SetText(tostring(db[key]));editors[#editors+1]={kind="number",key=key,widget=e,min=min,max=max};y=y-30;if tip then note(tip)end
 end
 local function minutes(key,title,min,max,tip)
  label(content,title,0,y,470);local e=CreateFrame("EditBox",nil,content,"InputBoxTemplate");e:SetSize(130,24);e:SetPoint("TOPLEFT",510,y+3);e:SetAutoFocus(false);e:SetMaxLetters(8);e:SetText(tostring(math.max(min,math.floor((db[key] or 0)/60))));editors[#editors+1]={kind="minutes",key=key,widget=e,min=min,max=max};y=y-30;if tip then note(tip)end
 end
 local function check(key,title)
  local c=CreateFrame("CheckButton",nil,content,"UICheckButtonTemplate");c:SetPoint("TOPLEFT",0,y);c:SetChecked(db[key]);label(content,title,34,y-6,625);editors[#editors+1]={kind="bool",key=key,widget=c};y=y-36
 end
 local function text(key,title)
  note(title);local e=CreateFrame("EditBox",nil,content,"InputBoxTemplate");e:SetSize(630,26);e:SetPoint("TOPLEFT",8,y);e:SetAutoFocus(false);e:SetMaxLetters(250);e:SetText(db[key] or "");editors[#editors+1]={kind="text",key=key,widget=e};y=y-42
 end
 if tab=="Help" then note(helpText)
 elseif tab=="PvP Log" then
  note("Lifetime PvP high score: "..tostring(db.pvpKills or 0).." kills    Deaths: "..tostring(db.pvpDeaths or 0).."    Stored rows: "..tostring(#(db.pvpLog or {})).." / 2000")
  note("Who killed you is shown only when Forever supplies a readable attacker identity. Unknown means the event did not expose one; Rektflix never guesses.")
  for i,mode in ipairs({"Newest","Oldest","Kills first","Deaths first"})do button(content,mode,(i-1)*160,y,150,function()db.pvpLogSort=mode;buildPanel("PvP Log")end)end;y=y-42
  local clear=button(content,"Clear log",0,y,150,function(self)if self.rfConfirm then db.pvpLog={};db.pvpKills=0;db.pvpDeaths=0;buildPanel("PvP Log")else self.rfConfirm=true;self:SetText("Click again to clear")end end)
  button(content,"Export copyable log",165,y,190,exportPvpLog);y=y-42
  for i,row in ipairs(sortedPvpLog())do if i>100 then note("Showing 100 rows. Export includes all stored rows.");break end;note(string.format("#%s  %s  %s  %s",tostring(row.n or "?"),row.kind or "?",date and date("%Y-%m-%d %H:%M:%S",row.time or 0)or tostring(row.time or 0),row.other or "Unknown"))end
 elseif tab=="Triggers" then
  note("Forever's direct kill/death events are supplemented by the Windows companion reading Blizzard's external combat log.")
  check("myPvpKills","My PvP killing blows / honorable kill credit");check("partyPvpKills","Party members' PvP killing blows");check("myDeath","My death");check("nearbyPlayerDeaths","Nearby player deaths in event/log range");check("myNpcKills","My creature kills");check("interrupts","My interrupts")
  check("spellCasts","Enable successful spell-cast ID triggers");text("spellIds","My successful spell casts: spell IDs, separated by commas")
  check("lootChatLogging","Enable watched-item chat logging (stores chat on disk)");text("lootIds","Watched item IDs: matching loot or chat links can trigger; not drop-confirmation")
 elseif tab=="Storage" then
  number("bufferLimitGB","Maximum buffer disk space (GB)",1,100,"Capture stops at this limit. Saved clips are never auto-deleted.")
  number("minimumFreeGB","Keep this much disk space free (GB)",1,100)
  note("Clip destination is set in the Windows app. Recovery runs there on the next capture start. Completed fragments are durable; the most recent data may be lost after power failure.")
  check("showBar","Show the compact in-game controls")
 else
  minutes("bufferSeconds","Rolling buffer duration (minutes, max 300 / 5 hours)",1,300,"Always recording while WoW is running and the Windows app is armed.")
  number("beforeSeconds","Automatic clip: seconds before event",0,18000)
  number("afterSeconds","Automatic clip: seconds after event",0,300)
  number("quickOne","Save button 1: last seconds",5,18000);number("quickTwo","Save button 2: last seconds",5,18000);number("quickThree","Save button 3: last seconds",5,18000)
  number("width","Output width (pixels)",640,3840);number("height","Output height (pixels)",360,2160)
  number("fps","Frame rate (15-60 FPS)",15,60);number("bitrateMbps","Video bitrate / quality (2-50 Mbps)",2,50)
  check("hardwareEncoder","Use hardware video encoding");check("systemAudio","Record system audio (includes other apps)");check("microphone","Record default microphone");check("cursor","Include cursor")
  note("Storage guide: five hours at 8 Mbps is roughly 18 GB before audio. Raise the buffer disk limit on the Storage tab if needed.")
 end
 content:SetHeight(math.max(430,-y+20))
 button(panel,"Apply & Reload UI",20,-574,190,function()
  if InCombatLockdown() then say("Apply after combat ends.");return end
  if not readEditors()then return end
  db.revision=tostring(GetServerTime()).."-"..tostring(math.floor(GetTime()*1000))
  ReloadUI()
 end)
 button(panel,"Help manual",225,-574,150,function()if readEditors()then buildPanel("Help")end end)
 label(panel,"WoW restart required after first installing the addon.",390,-581,330)
 panel:Show()
end
local function createBar()
 bar=CreateFrame("Frame","RektflixBar",UIParent,"BackdropTemplate");bar:SetSize(400,74);bar:SetPoint("TOP",0,-70);bar:SetFrameStrata("HIGH");backdrop(bar)
 bar:SetMovable(true);bar:EnableMouse(true);bar:RegisterForDrag("LeftButton");bar:SetScript("OnDragStart",bar.StartMoving);bar:SetScript("OnDragStop",function(self)self:StopMovingOrSizing();local point,_,relative,x,y=self:GetPoint();db.barPoint=point;db.barRelative=relative;db.barX=x;db.barY=y end)
 if db.barPoint and db.barX and db.barY then bar:ClearAllPoints();bar:SetPoint(db.barPoint,UIParent,db.barRelative,db.barX,db.barY) end
 label(bar,"REKTFLIX  |  Check Windows app status",12,-10,376,"GameFontNormal")
 local function quick(n)send(n,0)end
 local function duration(n)if n%3600==0 then return (n/3600).."h" elseif n%60==0 then return (n/60).."m" else return n.."s" end end
 button(bar,"Save "..duration(db.quickOne),10,-36,88,function()quick(1)end)
 button(bar,"Save "..duration(db.quickTwo),100,-36,88,function()quick(2)end)
 button(bar,"Save "..duration(db.quickThree),190,-36,88,function()quick(3)end)
 iconButton(bar,"record",284,function()send(4)end,"Start saved recording")
 iconButton(bar,"stop",320,function()send(5)end,"Stop saved recording")
 iconButton(bar,"settings",356,function()buildPanel("Recording")end,"Open Rektflix settings")
 if not db.showBar then bar:Hide()end
end
local events=CreateFrame("Frame")
for _,event in ipairs({"ADDON_LOADED","PLAYER_LOGIN","PLAYER_ENTERING_WORLD","PARTY_KILL","PLAYER_PVP_KILLS_CHANGED","UNIT_DIED","PLAYER_DEAD"})do events:RegisterEvent(event)end
events:SetScript("OnEvent",function(_,event,a,b)
 if event=="ADDON_LOADED" and a=="Rektflix" then
  RektflixDB=type(RektflixDB)=="table" and RektflixDB or {};db=RektflixDB
  for k,v in pairs(defaults)do if db[k]==nil then db[k]=v end end
 elseif event=="PLAYER_LOGIN" and db then
  pvpReadyAt=GetTime()+10
  local ok,result=pcall(LoggingCombat,true)
  if not ok or not result then say("Could not enable combat logging. Type /combatlog and check the Windows app.")end
  if db.lootChatLogging then pcall(LoggingChat,true)end
  makeSignal();signal:Hide();createBar()
  if Settings and Settings.RegisterCanvasLayoutCategory then
   local p=CreateFrame("Frame");p.name="Rektflix";label(p,"Rektflix",20,-20,600,"GameFontNormalLarge")
   button(p,"Open settings",20,-60,180,function()buildPanel("Recording")end);button(p,"Help manual",210,-60,160,function()buildPanel("Help")end)
   local ok2,category=pcall(Settings.RegisterCanvasLayoutCategory,p,"Rektflix");if ok2 and category then pcall(Settings.RegisterAddOnCategory,category)end
  end
 elseif event=="PLAYER_ENTERING_WORLD" and db then
  C_Timer.After(2,function()if db then pcall(LoggingCombat,true)end end)
 elseif db and GetTime()>=pvpReadyAt then
  if event=="PARTY_KILL" and safeText(a) and safeText(b) then
   local playerGUID=UnitGUID and UnitGUID("player")
   if safeText(playerGUID) and a==playerGUID then
    if b:match("^Player%-") then lastPersonalKillAt=GetTime();addPvpLog("KILL",guidLabel(b),"PARTY_KILL");if db.myPvpKills then send(6)end
    elseif not b:match("^Player%-") and db.myNpcKills then send(10)end
   elseif b:match("^Player%-") then if db.partyPvpKills then send(7)end end
  elseif event=="PLAYER_PVP_KILLS_CHANGED" then
   if GetTime()-lastPersonalKillAt>2 then addPvpLog("KILL","Unknown player","PLAYER_PVP_KILLS_CHANGED")end
   if db.myPvpKills then send(6)end
  elseif event=="UNIT_DIED" and db.nearbyPlayerDeaths and safeText(a) and a:match("^Player%-") then send(8)
  elseif event=="PLAYER_DEAD" then addPvpLog("DEATH","Unknown","PLAYER_DEAD");if db.myDeath then send(9)end
  end
 end
end)
SLASH_REKTFLIX1="/rektflix";SLASH_REKTFLIX2="/rf"
SlashCmdList.REKTFLIX=function(msg)
 if not db then return end
 msg=string.lower(msg or "")
 if msg=="help" then buildPanel("Help")
 elseif msg=="log"or msg=="logs"then buildPanel("PvP Log")
 elseif msg=="bar" then db.showBar=not db.showBar;bar:SetShown(db.showBar)
 elseif msg=="save" then send(1)
 else buildPanel("Recording")end
end
