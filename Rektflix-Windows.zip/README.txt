REKTFLIX 0.1.3 FOREVER PREVIEW
'n kill.

WHAT IT IS
Rektflix is a self-contained Windows recorder plus a World of Warcraft Classic
addon. The Windows app continuously records the selected WoW window into a
disk-backed rolling buffer. The addon provides settings, a draggable control
bar, /rf and /rektflix commands, automatic-event settings, and an in-game help
manual. Friends do not need OBS or another recorder; they do need this Windows
app if they want recording. The addon alone cannot create video files.

START
1. Extract the whole Rektflix folder. Do not run it from inside the ZIP.
2. Open Rektflix.exe. Nothing else needs to be installed; no OBS is required.
3. Confirm the detected WoW Forever folder, or choose the `_classic_beta_`
   folder containing WowB.exe, then press Install / update addon.
4. Restart WoW after the first addon installation.
5. Open WoW, make sure Rektflix says BUFFER RECORDING, and use /rf.
6. Make one test clip. Confirm direct events or fresh combat-log lines appear
   in the app before relying on automatic kill triggers.

DISK SPACE CLEARER (OPTIONAL)
The first-run setup offers Disk Space Clearer before the addon step, and the same
screen remains available under Game & setup. It scans only the drive you pick;
the normal Windows drive is selected by default. Results appear progressively
as understandable collections, largest first. System-managed folders, game and
Rektflix working files and reparse points are skipped. Small files do not become
standalone results, but they count when many of them make a folder collection large.

Expand a collection to include or exclude individual files, or choose its entire
folder; the global mode can apply whole-folder moves everywhere. Installer and
program collections always keep their folders together to protect dependencies.
Nothing moves until you confirm the destination, required space and expected
space freed. You can use an existing external-drive folder
or optionally create a dated Rektflix Space Vault. Every file is copied to a
temporary name, flushed, SHA-256 verified, renamed without overwriting, and
only then removed from its source. A restoration manifest records each step.
Cancel keeps completed files valid and pending sources untouched. If the move
or app is interrupted, the next Disk Space Clearer run offers to resume it; you can
also choose Resume interrupted move and select its restoration manifest.

The app uses built-in Windows capture, H.264 and AAC components. No OBS setup,
account, cloud upload, game injection or automated keypresses are used.

RECORDING CONTROLS
- The rolling buffer records whenever WoW is visible and the app is armed.
- Three user-settable buttons save the last chosen number of seconds.
- Record starts a separately saved clip. Stop ends that clip; it does not stop
  the rolling buffer. Disarm stops capture.
- Automatic events use independently settable before/after durations.
- Automatic triggers that overlap are merged. Manual and Save Last clips stay
  separate.

SETTINGS
Buffer: 1-300 minutes (five hours). New installs reserve up to 15 GB for the
rolling buffer by default. Quick-save: 5 seconds up to the buffer duration.
Automatic before: 0 seconds up to the buffer. Automatic after: 0-300 seconds.
Output: 640x360 through 3840x2160, 15-60 FPS, 2-50 Mbps bitrate.
Audio: default system playback and optional default microphone.
Other: hardware/software encoding, cursor, clip folder, buffer quota, disk
reserve, autostart, minimize to tray, triggers, watched IDs and a PvP ledger.
The in-app help manual includes recommended H.264 bitrate ranges for every
supported resolution/FPS class, expected quality, and hourly storage estimates.

TRIGGERS
Supported settings include your PvP killing blows / honorable kill credit, party PvP killing blows,
your death, nearby player deaths, creature kills, interrupts, selected spell
casts (with a separate enable checkbox), and selected item links seen in the
chat log. Normal “You receive loot” messages generally contain item hyperlinks
and can match, as can manually linked items. A watched item link is not proof
of a new drop; any logged matching item link may trigger.

On Forever, the addon directly listens for PARTY_KILL where identities are
readable, PLAYER_PVP_KILLS_CHANGED for honorable kill credit, UNIT_DIED for
enabled nearby-player deaths, and PLAYER_DEAD for your death. Forever may mark
some identities secret; Rektflix does not bypass that restriction. The Windows
app also reads Blizzard's external combat log as a fallback and for richer
optional triggers. Nearby means only events Blizzard sends in event/log range,
not everyone dying across the whole zone or world. The addon enables combat
logging at login. Optional watched items also enable chat logging, which stores
chat locally.

PVP SCORE AND LOG
The addon's PvP Log tab keeps lifetime kills and deaths plus up to 2,000
numbered rows. It sorts newest, oldest, kills first or deaths first. Export
opens a copyable tab-separated report; Clear requires two clicks. /rf log opens
the ledger. A PARTY_KILL entry can retain the target GUID. Forever's
PLAYER_DEAD event does not always expose the killer, so Who Killed Me is shown
as Unknown when the client withholds that identity; Rektflix does not guess.

CRASH / POWER RECOVERY
Completed MP4 fragments and pending clip requests are written durably to disk.
After an interrupted recorder, the next recording start exports available
footage as a Recovered clip. A sudden power loss can still lose the latest
fragment or defeat a drive's own write cache; no app can promise otherwise.
Saved clips are never automatically deleted. At the configured quota or free-
space reserve, capture stops and preserves existing data.

LIMITATIONS OF THIS PREVIEW
Synthetic video, real Windows window capture, resize handling, 60 FPS, system
audio, clip playback, rolling eviction and forced-process recovery are tested
on this PC. The package detects Forever's WowB.exe, installs both the normal and
Camelot manifests, and handles the `_classic_beta_` layout. A live Forever
client/realm was not available on this PC, so its real PvP events, client addon
loading and the optical bridge still require one in-game validation. The addon
was executed in a mocked Lua 5.1 WoW API, not Blizzard's client. Treat automatic
recording as unverified until one real kill is confirmed. Manual Windows
controls remain the fallback.

FILES AND PRIVACY
Clips default to Videos\Rektflix. Settings, rolling-buffer fragments and
diagnostics are in %LOCALAPPDATA%\Rektflix. The companion never uploads video.
System audio includes all sound on the default device, potentially including
voice chat or private notifications. WoW's own combat/chat logs are separate
and Rektflix does not delete them.

SHARING
Share the produced .mp4 file. For a friend to record, share this entire ZIP;
they extract it and open Rektflix.exe. Windows may show an unsigned-app warning
because this preview has no paid code-signing certificate.

TROUBLESHOOTING
- WAITING FOR WOW: choose the `_classic_beta_` folder containing WowB.exe and
  restore the game window.
- No automatic clips: confirm fresh combat-log lines in the app; try /combatlog.
- No in-game controls: restart WoW after installing and type /rf.
- Black/stalled capture: use borderless/windowed mode, restore the window, and
  update the graphics driver. Try software encoding and lower resolution/FPS.
- No system sound: choose the desired Windows default playback device, then
  disarm/rearm. Changing devices during recording can require a restart.
- Open Diagnostics in the app to find diagnostics.txt and state.json.

SOURCE
The complete corresponding source and build scripts are included in Source.
Rektflix source is provided under the MIT License. Bundled Microsoft Visual C++
runtime files remain subject to Microsoft's license; see THIRD-PARTY-NOTICES.txt.
