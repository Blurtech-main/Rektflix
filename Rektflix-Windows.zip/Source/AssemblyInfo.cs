using System.Reflection;

[assembly: AssemblyTitle("Rektflix")]
[assembly: AssemblyDescription("Rolling replay recorder companion for World of Warcraft Classic")]
[assembly: AssemblyCompany("Rektflix contributors")]
[assembly: AssemblyProduct("Rektflix")]
[assembly: AssemblyCopyright("Copyright 2026 Rektflix contributors")]
[assembly: AssemblyVersion("0.1.4.0")]
[assembly: AssemblyFileVersion("0.1.4.0")]
[assembly: AssemblyInformationalVersion("0.1.4-disk-space-clearer")]
