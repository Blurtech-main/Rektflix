using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;

namespace ForeverRecorder {
public static class Disk {
    public static double Now { get { return (DateTime.UtcNow - new DateTime(1970,1,1)).TotalSeconds; } }
    public static T Read<T>(string p) { return new JavaScriptSerializer { MaxJsonLength=16*1024*1024 }.Deserialize<T>(File.ReadAllText(p)); }
    public static void Json(string p, object obj) { Atomic(p, Encoding.UTF8.GetBytes(new JavaScriptSerializer { MaxJsonLength=16*1024*1024 }.Serialize(obj))); }
    public static void Atomic(string p, byte[] bytes) {
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(p)));
        string tmp=p+"."+Guid.NewGuid().ToString("N")+".tmp";
        using(var f=new FileStream(tmp,FileMode.CreateNew,FileAccess.Write,FileShare.None,65536,FileOptions.WriteThrough)) { f.Write(bytes,0,bytes.Length); f.Flush(true); }
        if(File.Exists(p)) File.Replace(tmp,p,null); else File.Move(tmp,p);
    }
    public static void Log(string root,string text) {
        try { Directory.CreateDirectory(root); string p=Path.Combine(root,"diagnostics.txt");
            if(File.Exists(p)&&new FileInfo(p).Length>2*1024*1024) { File.Copy(p,p+".previous",true); File.WriteAllText(p,""); }
            File.AppendAllText(p,DateTime.Now.ToString("s")+" "+text+Environment.NewLine); } catch {}
    }
}
public sealed class Settings {
    public int Version { get; set; }=1;
    public string WowFolder { get; set; }="";
    public string ClipsFolder { get; set; }=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyVideos),"Rektflix");
    public int BufferSeconds { get; set; }=300;
    public int QuickOne {get;set;}=30;
    public int QuickTwo {get;set;}=60;
    public int QuickThree {get;set;}=120;
    public int BeforeSeconds { get; set; }=30;
    public int AfterSeconds { get; set; }=15;
    public int Width { get; set; }=1920;
    public int Height { get; set; }=1080;
    public int Fps { get; set; }=30;
    public int BitrateMbps { get; set; }=8;
    public int BufferLimitGB { get; set; }=15;
    public int MinimumFreeGB { get; set; }=2;
    public bool SystemAudio { get; set; }=true;
    public bool Microphone { get; set; }=false;
    public bool HardwareEncoder { get; set; }=true;
    public bool Cursor { get; set; }=true;
    public bool MyPvpKills { get; set; }=true;
    public bool PartyPvpKills { get; set; }=false;
    public bool NearbyPlayerDeaths { get; set; }=false;
    public bool MyDeath { get; set; }=true;
    public bool MyNpcKills { get; set; }=false;
    public bool Interrupts { get; set; }=false;
    public bool SpellCasts { get; set; }=false;
    public bool AutoStart { get; set; }=true;
    public bool MinimizeToTray { get; set; }=true;
    public string SpellIds { get; set; }="";
    public string LootIds { get; set; }="";
    public bool LootChatLogging { get; set; }=false;
    public string AddonRevision { get; set; }="";
    public bool FreeSpaceSetupSeen { get; set; }=false;
    public void Validate() {
        BufferSeconds=Clamp(BufferSeconds,15,18000); BeforeSeconds=Clamp(BeforeSeconds,0,BufferSeconds);
        QuickOne=Clamp(QuickOne,5,BufferSeconds);QuickTwo=Clamp(QuickTwo,5,BufferSeconds);QuickThree=Clamp(QuickThree,5,BufferSeconds);
        AfterSeconds=Clamp(AfterSeconds,0,300); Fps=Clamp(Fps,15,60); BitrateMbps=Clamp(BitrateMbps,2,50);
        Width=Clamp(Width,640,3840)/2*2; Height=Clamp(Height,360,2160)/2*2;
        BufferLimitGB=Clamp(BufferLimitGB,1,100); MinimumFreeGB=Clamp(MinimumFreeGB,1,100);
        if(!Path.IsPathRooted(ClipsFolder)) throw new ArgumentException("Choose an absolute clips folder.");
    }
    public static int Clamp(int n,int min,int max) {return Math.Min(max,Math.Max(min,n));}
}
public sealed class Trigger {
    public string Kind {get;set;}
    public string Victim {get;set;}
    public double Time {get;set;}
    public string Key {get;set;}
}
public sealed class CombatParser {
    readonly Settings settings;
    readonly Dictionary<string,double> recent=new Dictionary<string,double>();
    public CombatParser(Settings s) {settings=s;}
    public static List<string> Csv(string text) {
        var fields=new List<string>(); var value=new StringBuilder(); bool quoted=false;
        for(int i=0;i<text.Length;i++) { char c=text[i]; if(c=='"') { if(quoted&&i+1<text.Length&&text[i+1]=='"') {value.Append('"');i++;}else quoted=!quoted; }
            else if(c==','&&!quoted) { fields.Add(value.ToString()); value.Clear(); } else value.Append(c); }
        if(quoted) return new List<string>(); fields.Add(value.ToString()); return fields;
    }
    static ulong Flags(string s) { ulong v; return ulong.TryParse(s.StartsWith("0x")?s.Substring(2):s,System.Globalization.NumberStyles.HexNumber,null,out v)?v:0; }
    public static HashSet<int> Ids(string s) {var h=new HashSet<int>(); foreach(var x in Regex.Split(s??"",@"\D+")) {int n;if(int.TryParse(x,out n)&&n>0)h.Add(n);}return h;}
    public Trigger Parse(string line,double now) {
        var m=Regex.Match(line,@"\s{2,}([A-Z][A-Z_]+,.*)$"); if(!m.Success)return null;
        var a=Csv(m.Groups[1].Value); if(a.Count<9)return null;
        string kind=a[0],source=a[1],dest=a[5]; ulong sf=Flags(a[3]),df=Flags(a[7]);
        bool mine=(sf&1)!=0,party=(sf&2)!=0,player=dest.StartsWith("Player-",StringComparison.Ordinal),hostile=(df&0x40)!=0;
        string reason=null;
        if(kind=="PARTY_KILL") {
            if(player&&hostile&&mine&&settings.MyPvpKills) reason="My PvP kill";
            else if(player&&hostile&&party&&settings.PartyPvpKills) reason="Party PvP kill";
            else if(!player&&mine&&settings.MyNpcKills) reason="My creature kill";
        }
        if(kind=="UNIT_DIED"&&player) {
            if((df&1)!=0&&settings.MyDeath) reason="My death";
            else if(settings.NearbyPlayerDeaths)reason="Nearby player death";
        }
        if(kind=="SPELL_INTERRUPT"&&mine&&settings.Interrupts)reason="My interrupt";
        int spell;
        if(kind=="SPELL_CAST_SUCCESS"&&settings.SpellCasts&&mine&&a.Count>9&&int.TryParse(a[9],out spell)&&Ids(settings.SpellIds).Contains(spell))reason="Spell "+spell;
        if(reason==null)return null;
        string key=(kind=="PARTY_KILL"||kind=="UNIT_DIED"?"death":kind)+":"+dest;
        double last; if(recent.TryGetValue(key,out last)&&now-last<3)return null;
        recent[key]=now;
        foreach(var k in recent.Where(x=>now-x.Value>30).Select(x=>x.Key).ToArray())recent.Remove(k);
        return new Trigger {Kind=reason,Victim=a[6],Time=now,Key=key};
    }
    public Trigger ParseLoot(string line,double now) {
        if(!settings.LootChatLogging)return null;
        var ids=Ids(settings.LootIds);
        foreach(Match m in Regex.Matches(line,@"\|Hitem:(\d+):")) {
            int id; if(int.TryParse(m.Groups[1].Value,out id)&&ids.Contains(id))
                return new Trigger {Kind="Watched item seen in chat",Victim="Item "+id,Time=now,Key="loot:"+id};
        } return null;
    }
}
// Keep a handle open, retain partial UTF-8 lines, and never replay an existing log on startup.
public sealed class LogTail : IDisposable {
    FileStream stream; string path=""; DateTime creation;Decoder decoder=Encoding.UTF8.GetDecoder(); StringBuilder pending=new StringBuilder();
    bool initialized; public string PathName {get{return path;}} public double LastLine {get;private set;}
    public IEnumerable<string> Poll(string folder,string pattern) {
        var lines=new List<string>(); if(!Directory.Exists(folder)){initialized=true;return lines;}
        string next=Directory.GetFiles(folder,pattern).OrderByDescending(File.GetLastWriteTimeUtc).ThenBy(x=>x).FirstOrDefault();
        if(next==null){initialized=true;return lines;}
        var nextCreation=File.GetCreationTimeUtc(next);
        if(next!=path || stream==null||nextCreation!=creation) { if(stream!=null)stream.Dispose(); stream=new FileStream(next,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete); path=next;creation=nextCreation;
            if(!initialized)stream.Position=stream.Length; initialized=true; pending.Clear();decoder=Encoding.UTF8.GetDecoder(); }
        if(stream.Length<stream.Position) {stream.Position=0;pending.Clear();decoder=Encoding.UTF8.GetDecoder();}
        byte[] bytes=new byte[65536]; char[] chars=new char[65536]; int total=0;
        while(stream.Position<stream.Length&&total<2*1024*1024) { int n=stream.Read(bytes,0,bytes.Length);if(n==0)break;total+=n;
            int c=decoder.GetChars(bytes,0,n,chars,0,false);pending.Append(chars,0,c); }
        string text=pending.ToString(); int start=0,pos;
        while((pos=text.IndexOf('\n',start))>=0) {string line=text.Substring(start,pos-start).TrimEnd('\r');if(line.Length<65536)lines.Add(line);start=pos+1;}
        pending.Clear(); if(text.Length-start<65536)pending.Append(text.Substring(start));
        if(lines.Count>0)LastLine=Disk.Now; return lines;
    }
    public void Dispose(){if(stream!=null)stream.Dispose();}
}
public static class AddonSettings {
    // Parse a deliberately flat scalar schema. Never execute Lua from SavedVariables.
    public static bool Import(string text,Settings s) {
        var vals=new Dictionary<string,string>();
        foreach(Match m in Regex.Matches(text,"\\[\"([A-Za-z]+)\"\\]\\s*=\\s*(\"[^\"\\r\\n]*\"|true|false|-?\\d+)"))vals[m.Groups[1].Value]=m.Groups[2].Value.Trim('"');
        string rev; if(!vals.TryGetValue("revision",out rev)||rev==s.AddonRevision)return false;
        var map=new Dictionary<string,string>{{"bufferSeconds","BufferSeconds"},{"beforeSeconds","BeforeSeconds"},{"afterSeconds","AfterSeconds"},{"width","Width"},{"height","Height"},{"fps","Fps"},{"bitrateMbps","BitrateMbps"},{"bufferLimitGB","BufferLimitGB"},{"minimumFreeGB","MinimumFreeGB"},{"systemAudio","SystemAudio"},{"microphone","Microphone"},{"hardwareEncoder","HardwareEncoder"},{"cursor","Cursor"},{"myPvpKills","MyPvpKills"},{"partyPvpKills","PartyPvpKills"},{"nearbyPlayerDeaths","NearbyPlayerDeaths"},{"myDeath","MyDeath"},{"myNpcKills","MyNpcKills"},{"interrupts","Interrupts"},{"spellCasts","SpellCasts"},{"spellIds","SpellIds"},{"lootIds","LootIds"},{"lootChatLogging","LootChatLogging"}};
        map["quickOne"]="QuickOne";map["quickTwo"]="QuickTwo";map["quickThree"]="QuickThree";
        foreach(var kv in map) {string v;if(!vals.TryGetValue(kv.Key,out v))continue;var p=typeof(Settings).GetProperty(kv.Value);
            if(p.PropertyType==typeof(int)){int n;if(int.TryParse(v,out n))p.SetValue(s,n,null);}else if(p.PropertyType==typeof(bool)){bool b;if(bool.TryParse(v,out b))p.SetValue(s,b,null);}else p.SetValue(s,v,null);}
        s.Validate();s.AddonRevision=rev;return true;
    }
}
}
