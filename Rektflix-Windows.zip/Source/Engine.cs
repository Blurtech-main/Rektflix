using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;

namespace ForeverRecorder {
public sealed class WorkerState {
    public double Heartbeat {get;set;} public string Message {get;set;} public string Error {get;set;}
    public double BufferSeconds {get;set;} public double LastFragment {get;set;} public double LastCombatLine {get;set;}
    public long CombatLines {get;set;} public int PendingClips {get;set;} public int Recovered {get;set;}
    public bool ManualRecording {get;set;} public double LastCommand {get;set;}
}
public static class Native {
    [DllImport("user32.dll")]public static extern bool IsWindow(IntPtr h);
    [DllImport("user32.dll")]public static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")]public static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")]public static extern bool ShowWindow(IntPtr h,int n);
    [DllImport("kernel32.dll")]public static extern uint SetErrorMode(uint mode);
}
public static class Engine {
    public static int Run(string root,long handle,int parent,string testImage,int seconds) {
        Native.SetErrorMode(0x0001|0x0002|0x8000);var state=new WorkerState{Message="Starting recorder"};NativeCapture recorder=null;FragmentStream stream=null;BufferStore store=null;
        var complete=new ManualResetEventSlim(false);string failure=null;bool stopped=false;
        try {
            var s=Disk.Read<Settings>(Path.Combine(root,"settings.json"));s.Validate();Directory.CreateDirectory(s.ClipsFolder);
            string bufferRoot=Path.Combine(root,"buffer");Directory.CreateDirectory(bufferRoot);state.Recovered=BufferStore.Recover(bufferRoot,s);
            string folder=Path.Combine(bufferRoot,"session-"+DateTime.UtcNow.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N").Substring(0,8));
            store=new BufferStore(folder,s,Disk.Now);stream=new FragmentStream(folder);stream.Committed+=f=>{store.Add(f);state.LastFragment=Disk.Now;};
            recorder=new NativeCapture();complete=recorder.Complete;
            var combat=new LogTail();var chat=new LogTail();var parser=new CombatParser(s);var bridge=new SignalBridge();
            string logs=Path.Combine(s.WowFolder,"Logs");
            // Establish EOF cursors before recording so stale logs cannot trigger old kills.
            combat.Poll(logs,"WoWCombatLog*.txt");if(s.LootChatLogging)chat.Poll(logs,"WoWChatLog*.txt");
            recorder.Start(stream,new IntPtr(handle),s,testImage!=null);double began=Disk.Now,lastStatus=0;bool testTriggered=false;
            while(true){
                failure=recorder.Error;if(failure!=null)throw new IOException("Capture failed: "+failure);
                if(stream.Failure!=null)throw new IOException("Buffer failed",stream.Failure);
                if(complete.IsSet)throw new IOException("Recorder stopped unexpectedly");
                if(File.Exists(Path.Combine(root,"stop.request")))break;
                if(parent>0){try{if(Process.GetProcessById(parent).HasExited)throw new IOException("App closed unexpectedly");}catch(ArgumentException){throw new IOException("App closed unexpectedly; buffer retained for next launch");}}
                if(testImage==null&&(!Native.IsWindow(new IntPtr(handle))||Native.IsIconic(new IntPtr(handle))))break;
                foreach(var line in combat.Poll(logs,"WoWCombatLog*.txt")){state.CombatLines++;var t=parser.Parse(line,Disk.Now);if(t!=null)store.Trigger(t.Kind+": "+t.Victim,t.Time);}
                if(s.LootChatLogging)foreach(var line in chat.Poll(logs,"WoWChatLog*.txt")){var t=parser.ParseLoot(line,Disk.Now);if(t!=null)store.Trigger(t.Kind+": "+t.Victim,t.Time);}
                foreach(string p in Directory.GetFiles(root,"save-*.request")){int code;if(int.TryParse(File.ReadAllText(p),out code)){store.Command(code);state.LastCommand=Disk.Now;}File.Delete(p);}
                if(testImage==null){int code=bridge.Poll(new IntPtr(handle));if(code!=0){
                    if(code<=5)store.Command(code);else store.Trigger(code==6?"Forever PvP kill credit":code==7?"Forever party PvP kill":code==8?"Forever nearby player death":code==9?"Forever own death":"Forever creature kill",Disk.Now);
                    state.LastCommand=Disk.Now;}}
                if(seconds>0&&!testTriggered&&Disk.Now-began>seconds/2){store.Trigger("Recorder integration test",Disk.Now);testTriggered=true;}
                if(seconds>0&&Disk.Now-began>=seconds)break;
                store.Tick();
                if(Disk.Now-began>25&&(state.LastFragment==0||Disk.Now-state.LastFragment>20))throw new IOException("No new video fragments for 20 seconds. Recording stopped; existing buffer retained.");
                if(Disk.Now-lastStatus>1){
                    var drive=new DriveInfo(Path.GetPathRoot(root));var outputDrive=new DriveInfo(Path.GetPathRoot(s.ClipsFolder));
                    if(drive.AvailableFreeSpace<s.MinimumFreeGB*1024L*1024*1024||outputDrive.AvailableFreeSpace<s.MinimumFreeGB*1024L*1024*1024)throw new IOException("Free disk reserve reached. Recording stopped; clips and buffer preserved.");
                    state.Heartbeat=Disk.Now;state.BufferSeconds=store.Seconds;state.LastCombatLine=combat.LastLine;state.PendingClips=store.Jobs.Count;
                    state.ManualRecording=store.Jobs.Any(x=>x.Manual);
                    state.Message=state.LastFragment==0?"Starting video capture":state.CombatLines==0?"Recording buffer / waiting for combat-log events":"Recording buffer / combat log active";
                    Disk.Json(Path.Combine(root,"state.json"),state);lastStatus=Disk.Now;
                }
                Thread.Sleep(100);
            }
            recorder.Stop();if(!complete.Wait(15000))throw new IOException("Recorder did not finish closing; buffer retained");stopped=true;
            if(recorder.Error!=null)throw new IOException(recorder.Error);store.Close();combat.Dispose();chat.Dispose();
            state.Message="Recorder stopped";state.Heartbeat=Disk.Now;Disk.Json(Path.Combine(root,"state.json"),state);return 0;
        }catch(Exception ex){state.Error=ex.ToString();state.Message="Recording stopped: "+ex.Message;state.Heartbeat=Disk.Now;Disk.Log(root,state.Error);try{Disk.Json(Path.Combine(root,"state.json"),state);}catch{}return 2;}
        finally{if(recorder!=null){try{if(!stopped){recorder.Stop();complete.Wait(3000);}recorder.Dispose();}catch{}}if(stream!=null)stream.Dispose();}
    }
}
public static class Wow {
    static readonly string[] ExeNames={"WowB.exe","Wow.exe","WowClassic.exe","WowT.exe"};
    static readonly string[] ProcessNames={"WowB","Wow","WowClassic","WowT"};
    public static string Executable(string folder){if(string.IsNullOrWhiteSpace(folder))return null;return ExeNames.Select(x=>Path.Combine(folder,x)).FirstOrDefault(File.Exists);}
    public static IEnumerable<string> Discover(){
        var roots=new List<string>();
        foreach(string name in ProcessNames)foreach(var p in Process.GetProcessesByName(name)){try{roots.Add(Path.GetDirectoryName(p.MainModule.FileName));}catch{}finally{p.Dispose();}}
        foreach(string baseDir in new[]{Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),@"C:\Games",@"D:\Games",@"D:\"})
            foreach(string flavor in new[]{"_classic_beta_","_forever_","_classic_era_"})roots.Add(Path.Combine(baseDir,"World of Warcraft",flavor));
        return roots.Where(x=>Executable(x)!=null).Distinct(StringComparer.OrdinalIgnoreCase);
    }
    public static Process Find(string folder){foreach(string name in ProcessNames)foreach(var p in Process.GetProcessesByName(name)){try{if(string.Equals(Path.GetDirectoryName(p.MainModule.FileName),folder,StringComparison.OrdinalIgnoreCase)&&p.MainWindowHandle!=IntPtr.Zero&&!Native.IsIconic(p.MainWindowHandle))return p;}catch{}p.Dispose();}return null;}
    public static void Install(string folder){
        if(Executable(folder)==null)throw new IOException("Select the WoW Forever / Classic game folder containing WowB.exe, Wow.exe or WowClassic.exe.");
        string source=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Addon","Rektflix"),target=Path.Combine(folder,"Interface","AddOns","Rektflix");Directory.CreateDirectory(target);
        foreach(string name in new[]{"Rektflix.toc","Rektflix_Camelot.toc","Rektflix.lua"}){
            string dest=Path.Combine(target,name);byte[] data=File.ReadAllBytes(Path.Combine(source,name));
            if(File.Exists(dest)&&File.ReadAllBytes(dest).SequenceEqual(data))continue;
            if(File.Exists(dest))File.Copy(dest,dest+".previous",true);Disk.Atomic(dest,data);
        }
    }
}
}
