using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace ForeverRecorder {
public sealed class Box { public int Offset,Size,Header; public string Type; public int Data {get{return Offset+Header;}} }
public sealed class Track {public uint Id,Scale,Duration,Flags;public bool Video;public ulong NextDecode;}
public sealed class Fragment {public string File {get;set;} public double Start {get;set;} public double End {get;set;} public bool Keyframe {get;set;} public bool Video {get;set;} public long Bytes {get;set;} }
public static class Mp4 {
    public static uint U32(byte[] b,int p){return ((uint)b[p]<<24)|((uint)b[p+1]<<16)|((uint)b[p+2]<<8)|b[p+3];}
    public static ulong U64(byte[] b,int p){return ((ulong)U32(b,p)<<32)|U32(b,p+4);}
    public static void Put32(byte[] b,int p,uint v){b[p]=(byte)(v>>24);b[p+1]=(byte)(v>>16);b[p+2]=(byte)(v>>8);b[p+3]=(byte)v;}
    public static void Put64(byte[] b,int p,ulong v){Put32(b,p,(uint)(v>>32));Put32(b,p+4,(uint)v);}
    public static List<Box> Boxes(byte[] b,int start,int end){
        var result=new List<Box>();for(int p=start;p+8<=end;){ulong size=U32(b,p);int h=8;if(size==1){if(p+16>end)throw new InvalidDataException("Short MP4 box");size=U64(b,p+8);h=16;}
            if(size==0)size=(ulong)(end-p);if(size<(ulong)h||size>int.MaxValue||p+(long)size>end)throw new InvalidDataException("Invalid MP4 box length");
            result.Add(new Box{Offset=p,Size=(int)size,Header=h,Type=Encoding.ASCII.GetString(b,p+4,4)});p+=(int)size;}return result;
    }
    static List<Box> Children(byte[] b,Box box){return Boxes(b,box.Data,box.Offset+box.Size);}
    public static Dictionary<uint,Track> Tracks(byte[] init){
        var result=new Dictionary<uint,Track>();var moov=Boxes(init,0,init.Length).First(x=>x.Type=="moov");var children=Children(init,moov);
        foreach(var trak in children.Where(x=>x.Type=="trak")){
            var tc=Children(init,trak);var tkhd=tc.First(x=>x.Type=="tkhd");int t=tkhd.Data;uint id=U32(init,t+(init[t]==1?20:12));
            var mdia=tc.First(x=>x.Type=="mdia");var mc=Children(init,mdia);var mdhd=mc.First(x=>x.Type=="mdhd");int d=mdhd.Data;
            var hdlr=mc.First(x=>x.Type=="hdlr");result[id]=new Track{Id=id,Scale=U32(init,d+(init[d]==1?20:12)),Video=Encoding.ASCII.GetString(init,hdlr.Data+8,4)=="vide"};
        }
        var mvex=children.FirstOrDefault(x=>x.Type=="mvex");if(mvex!=null)foreach(var box in Children(init,mvex).Where(x=>x.Type=="trex")){
            uint id=U32(init,box.Data+4);Track tr;if(result.TryGetValue(id,out tr)){tr.Duration=U32(init,box.Data+12);tr.Flags=U32(init,box.Data+20);}}
        return result;
    }
    public static Fragment Describe(byte[] bytes,Dictionary<uint,Track> tracks,double rebase=-1,bool advance=false){
        var fragment=new Fragment {Start=double.MaxValue,End=0,Bytes=bytes.Length};
        foreach(var moof in Boxes(bytes,0,bytes.Length).Where(x=>x.Type=="moof"))foreach(var traf in Children(bytes,moof).Where(x=>x.Type=="traf")){
            var children=Children(bytes,traf);var tfhd=children.First(x=>x.Type=="tfhd");int p=tfhd.Data;uint flags=U32(bytes,p)&0xffffff,id=U32(bytes,p+4);Track track;
            if(!tracks.TryGetValue(id,out track)||track.Scale==0)throw new InvalidDataException("Unknown MP4 track");p+=8;
            if((flags&1)!=0)p+=8;
            if((flags&2)!=0)p+=4;uint duration=track.Duration,sampleFlags=track.Flags;
            if((flags&8)!=0){duration=U32(bytes,p);p+=4;}if((flags&16)!=0)p+=4;if((flags&32)!=0)sampleFlags=U32(bytes,p);
            var tfdt=children.First(x=>x.Type=="tfdt");int dp=tfdt.Data;ulong decode=bytes[dp]==1?U64(bytes,dp+4):U32(bytes,dp+4);
            double begin=(double)decode/track.Scale;ulong total=0;bool first=true;
            foreach(var trun in children.Where(x=>x.Type=="trun")){
                p=trun.Data;uint f=U32(bytes,p)&0xffffff,count=U32(bytes,p+4);p+=8;if((f&1)!=0)p+=4;uint firstFlags=sampleFlags;
                if((f&4)!=0){firstFlags=U32(bytes,p);p+=4;}
                if(count>1000000)throw new InvalidDataException("Invalid sample count");
                for(uint i=0;i<count;i++){
                    uint dur=duration,fs=i==0?firstFlags:sampleFlags;
                    if((f&0x100)!=0){dur=U32(bytes,p);p+=4;}if((f&0x200)!=0)p+=4;if((f&0x400)!=0){fs=U32(bytes,p);p+=4;}if((f&0x800)!=0)p+=4;
                    if(first&&track.Video){fragment.Video=true;fragment.Keyframe=(fs&0x10000)==0;first=false;}total+=dur;
                }
            }
            fragment.Start=Math.Min(fragment.Start,begin);fragment.End=Math.Max(fragment.End,begin+(double)total/track.Scale);
            if(advance)track.NextDecode=decode+total;
            if(rebase>=0){ulong sub=(ulong)Math.Round(rebase*track.Scale);ulong value=decode>=sub?decode-sub:0;if(bytes[dp]==1)Put64(bytes,dp+4,value);else Put32(bytes,dp+4,(uint)value);}
        }
        if(fragment.Start==double.MaxValue)throw new InvalidDataException("Fragment has no timed samples");return fragment;
    }
    public static void ShiftOffsets(byte[] bytes,long delta){
        foreach(var moof in Boxes(bytes,0,bytes.Length).Where(x=>x.Type=="moof"))foreach(var traf in Children(bytes,moof).Where(x=>x.Type=="traf")){
            var tfhd=Children(bytes,traf).First(x=>x.Type=="tfhd");if((U32(bytes,tfhd.Data)&1)!=0){long previous=checked((long)U64(bytes,tfhd.Data+8));long next=checked(previous+delta);if(next<0)throw new InvalidDataException("Negative fragment offset");Put64(bytes,tfhd.Data+8,(ulong)next);}
        }
    }
    // The Windows fMP4 sink may omit tfdt and rely on cumulative sample durations.
    // Add explicit decode times before persisting fragments so any retained window can stand alone.
    public static byte[] AddDecodeTimes(byte[] bytes,Dictionary<uint,Track> tracks,out int growth){
        growth=0;using(var output=new MemoryStream()){
            foreach(var box in Boxes(bytes,0,bytes.Length)){
                if(box.Type!="moof"){output.Write(bytes,box.Offset,box.Size);continue;}
                using(var body=new MemoryStream()){
                    foreach(var child in Children(bytes,box)){
                        if(child.Type!="traf"||Children(bytes,child).Any(x=>x.Type=="tfdt")){body.Write(bytes,child.Offset,child.Size);continue;}
                        var tfhd=Children(bytes,child).First(x=>x.Type=="tfhd");uint id=U32(bytes,tfhd.Data+4);byte[] header=new byte[8];Put32(header,0,(uint)(child.Size+20));Encoding.ASCII.GetBytes("traf").CopyTo(header,4);body.Write(header,0,8);
                        // Decode time must precede sample runs: streaming demuxers consume trun immediately.
                        byte[] tfdt=new byte[20];Put32(tfdt,0,20);Encoding.ASCII.GetBytes("tfdt").CopyTo(tfdt,4);tfdt[8]=1;Put64(tfdt,12,tracks[id].NextDecode);
                        foreach(var part in Children(bytes,child)){body.Write(bytes,part.Offset,part.Size);if(part.Type=="tfhd")body.Write(tfdt,0,20);}growth+=20;
                    }
                    byte[] moofHeader=new byte[8];Put32(moofHeader,0,(uint)(body.Length+8));Encoding.ASCII.GetBytes("moof").CopyTo(moofHeader,4);output.Write(moofHeader,0,8);body.Position=0;body.CopyTo(output);
                }
            }return output.ToArray();
        }
    }
}
// Fragmented Media Foundation output is append-only. Each moof+mdat is committed independently.
public sealed class FragmentStream : Stream {
    readonly object gate=new object(); readonly string folder; readonly MemoryStream pending=new MemoryStream(),init=new MemoryStream();
    byte[] moof; long position,moofPosition;int sequence;Dictionary<uint,Track> tracks;
    public event Action<Fragment> Committed; public Exception Failure {get;private set;}
    public FragmentStream(string path){folder=path;Directory.CreateDirectory(folder);}
    public override void Write(byte[] b,int offset,int count){lock(gate){
        if(Failure!=null)throw new IOException("Fragment writer failed",Failure);
        try {pending.Position=pending.Length;pending.Write(b,offset,count);position+=count;byte[] data=pending.ToArray();int consumed=0;
            while(data.Length-consumed>=8){ulong size=Mp4.U32(data,consumed);int header=8;if(size==1){if(data.Length-consumed<16)break;size=Mp4.U64(data,consumed+8);header=16;}
                if(size<(ulong)header||size>128*1024*1024)throw new InvalidDataException("Unexpected recording fragment size");if((ulong)(data.Length-consumed)<size)break;
                byte[] box=new byte[(int)size];Buffer.BlockCopy(data,consumed,box,0,box.Length);string type=Encoding.ASCII.GetString(box,4,4);
                if(type=="ftyp"||type=="moov"){init.Write(box,0,box.Length);if(type=="moov"){byte[] ib=init.ToArray();tracks=Mp4.Tracks(ib);Disk.Atomic(Path.Combine(folder,"init.mp4"),ib);}}
                else if(type=="moof"){moof=box;moofPosition=position-data.Length+consumed;}
                else if(type=="mdat"&&moof!=null){if(tracks==null)throw new InvalidDataException("Missing initialization");byte[] fragment=new byte[moof.Length+box.Length];Buffer.BlockCopy(moof,0,fragment,0,moof.Length);Buffer.BlockCopy(box,0,fragment,moof.Length,box.Length);
                    Fragment meta;try{int growth;fragment=Mp4.AddDecodeTimes(fragment,tracks,out growth);Mp4.ShiftOffsets(fragment,-moofPosition+growth);meta=Mp4.Describe(fragment,tracks,-1,true);}catch{Disk.Atomic(Path.Combine(folder,"unparsed-fragment.bin"),fragment);throw;}meta.File=(++sequence).ToString("D8")+".frag";Disk.Atomic(Path.Combine(folder,meta.File),fragment);Disk.Json(Path.Combine(folder,meta.File+".json"),meta);moof=null;var cb=Committed;if(cb!=null)cb(meta);}
                consumed+=(int)size;
            }
            pending.SetLength(0);pending.Write(data,consumed,data.Length-consumed);
        }catch(Exception ex){Failure=ex;throw;}
    }}
    public override bool CanRead{get{return false;}} public override bool CanSeek{get{return false;}}public override bool CanWrite{get{return true;}}
    public override long Length{get{return position;}}public override long Position{get{return position;}set{throw new NotSupportedException();}}
    public override void Flush(){}public override int Read(byte[] b,int o,int c){throw new NotSupportedException();}
    public override long Seek(long o,SeekOrigin s){throw new NotSupportedException();}public override void SetLength(long v){if(v!=position)throw new NotSupportedException();}
}
public sealed class SessionInfo {public double Origin {get;set;} public bool Clean {get;set;} }
public sealed class ClipJob {public string Id {get;set;} public string Reason {get;set;} public double Start {get;set;} public double End {get;set;} public double Requested {get;set;} public bool Manual {get;set;} public bool Automatic {get;set;} }
public sealed class BufferStore {
    public readonly object Gate=new object(); public readonly string Folder;public readonly double Origin;
    public readonly List<Fragment> Fragments=new List<Fragment>();public readonly List<ClipJob> Jobs=new List<ClipJob>();readonly Settings settings;
    public BufferStore(string folder,Settings s,double origin){Folder=folder;settings=s;Origin=origin;Directory.CreateDirectory(folder);Disk.Json(Path.Combine(folder,"session.json"),new SessionInfo{Origin=origin});}
    public void Add(Fragment f){lock(Gate){Fragments.Add(f);}}
    public double Seconds {get{lock(Gate)return Fragments.Count==0?0:Fragments.Last().End-Fragments.First().Start;}}
    public void Trigger(string reason,double utc){lock(Gate){double at=Math.Max(0,utc-Origin);double from=Math.Max(0,at-settings.BeforeSeconds),to=at+settings.AfterSeconds;
        var job=Jobs.LastOrDefault(j=>j.Automatic&&j.End>=from);if(job!=null){job.End=Math.Max(job.End,to);if(job.Reason.Length<200)job.Reason+=" + "+reason;}
        else {job=new ClipJob{Id=Guid.NewGuid().ToString("N"),Reason=reason,Start=from,End=to,Requested=utc,Automatic=true};Jobs.Add(job);}Disk.Json(Path.Combine(Folder,job.Id+".job.json"),job);
    }}
    public void Command(int code){lock(Gate){double at=Disk.Now-Origin;
        if(code>=1&&code<=3){int duration=code==1?settings.QuickOne:code==2?settings.QuickTwo:settings.QuickThree;
            var j=new ClipJob{Id=Guid.NewGuid().ToString("N"),Reason="Save last "+duration+" seconds",Start=Math.Max(0,at-duration),End=at,Requested=Disk.Now};Jobs.Add(j);Disk.Json(Path.Combine(Folder,j.Id+".job.json"),j);}
        else if(code==4&&!Jobs.Any(x=>x.Manual)){var j=new ClipJob{Id=Guid.NewGuid().ToString("N"),Reason="Manual recording",Start=at,End=at+86400,Requested=Disk.Now,Manual=true};Jobs.Add(j);Disk.Json(Path.Combine(Folder,j.Id+".job.json"),j);}
        else if(code==5){foreach(var j in Jobs.Where(x=>x.Manual)){j.Manual=false;j.End=at;Disk.Json(Path.Combine(Folder,j.Id+".job.json"),j);}}
    }}
    public void Tick(bool finish=false){lock(Gate){
        if(Fragments.Count==0)return;
        foreach(var job in Jobs.ToArray())if(finish||Fragments.Max(x=>x.End)>=job.End){Export(Folder,Fragments,job,settings.ClipsFolder,finish&&Fragments.Max(x=>x.End)<job.End,settings.MinimumFreeGB);File.Delete(Path.Combine(Folder,job.Id+".job.json"));Jobs.Remove(job);}
        double cutoff=Fragments.Last().End-settings.BufferSeconds;if(Jobs.Count>0)cutoff=Math.Min(cutoff,Jobs.Min(x=>x.Start));
        var key=Fragments.LastOrDefault(x=>x.Video&&x.Keyframe&&x.Start<=cutoff);if(key!=null)foreach(var f in Fragments.Where(x=>x.End<key.Start).ToArray()){File.Delete(Path.Combine(Folder,f.File));File.Delete(Path.Combine(Folder,f.File+".json"));Fragments.Remove(f);}
        if(Fragments.Sum(x=>x.Bytes)>settings.BufferLimitGB*1024L*1024*1024)throw new IOException("Buffer disk limit reached. Lower buffer duration/bitrate or raise its disk limit. Footage preserved.");
    }}
    public void Close(){Tick(true);Disk.Json(Path.Combine(Folder,"session.json"),new SessionInfo{Origin=Origin,Clean=true});}
    public static string Export(string folder,List<Fragment> all,ClipJob job,string output,bool partial,int reserveGB=0){
        var startKey=all.LastOrDefault(x=>x.Video&&x.Keyframe&&x.Start<=job.Start)??all.FirstOrDefault(x=>x.Video&&x.Keyframe);
        if(startKey==null)throw new InvalidDataException("No complete video keyframe available yet");
        int index=all.IndexOf(startKey);var selected=all.Skip(index).Where(x=>x.Start<=job.End).ToList();if(selected.Count==0)throw new InvalidDataException("No footage for this clip");
        Directory.CreateDirectory(output);string name=new DateTime(1970,1,1).AddSeconds(job.Requested).ToLocalTime().ToString("yyyy-MM-dd_HH-mm-ss")+"_"+(partial?"Recovered_":"")+job.Id.Substring(0,8)+".mp4";
        string path=Path.Combine(output,name);if(File.Exists(path))return path;string temp=path+".partial";
        byte[] init=File.ReadAllBytes(Path.Combine(folder,"init.mp4"));var tracks=Mp4.Tracks(init);double origin=selected.Min(x=>x.Start);
        if(new DriveInfo(Path.GetPathRoot(output)).AvailableFreeSpace<selected.Sum(x=>x.Bytes)+init.Length+reserveGB*1024L*1024*1024)throw new IOException("Not enough disk space to export safely. Buffer and pending clip retained; free space and restart.");
        using(var f=new FileStream(temp,FileMode.Create,FileAccess.Write,FileShare.None,65536,FileOptions.WriteThrough)){
            f.Write(init,0,init.Length);foreach(var entry in selected){byte[] bytes=File.ReadAllBytes(Path.Combine(folder,entry.File));Mp4.Describe(bytes,tracks,origin);Mp4.ShiftOffsets(bytes,f.Position);f.Write(bytes,0,bytes.Length);}f.Flush(true);
        }
        File.Move(temp,path);Disk.Json(path+".json",new {job.Reason,job.Requested,RequestedBeforeStart=job.Start,RequestedEnd=job.End,ActualStart=origin,ActualEnd=selected.Max(x=>x.End),Partial=partial,Format="Fragmented MP4 / H.264 + AAC"});return path;
    }
    public static int Recover(string root,Settings s){int recovered=0;if(!Directory.Exists(root))return 0;
        foreach(string folder in Directory.GetDirectories(root,"session-*")){
            string infoPath=Path.Combine(folder,"session.json");if(!File.Exists(infoPath))continue;
            SessionInfo info;try{info=Disk.Read<SessionInfo>(infoPath);}catch(Exception ex){Disk.Log(root,"Recovery left invalid session untouched: "+folder+" "+ex.Message);continue;}
            var all=new List<Fragment>();string initPath=Path.Combine(folder,"init.mp4");
            if(!info.Clean&&File.Exists(initPath)){
                Dictionary<uint,Track> tracks;try{tracks=Mp4.Tracks(File.ReadAllBytes(initPath));}catch(Exception ex){Disk.Log(root,"Recovery left invalid initialization untouched: "+folder+" "+ex.Message);continue;}
                // A power cut can occur after the durable fragment rename but before its JSON sidecar.
                // Rebuild metadata from the media itself so those complete fragments are not lost.
                foreach(string p in Directory.GetFiles(folder,"*.frag")){try{var f=Mp4.Describe(File.ReadAllBytes(p),tracks);f.File=Path.GetFileName(p);all.Add(f);}catch(Exception ex){Disk.Log(root,"Skipped incomplete fragment: "+p+" "+ex.Message);}}
            }
            all=all.OrderBy(x=>x.File).ToList();if(!info.Clean&&all.Count>0){
                var jobs=new List<ClipJob>();foreach(string jobPath in Directory.GetFiles(folder,"*.job.json")){try{var job=Disk.Read<ClipJob>(jobPath);Guid id;if(!Guid.TryParseExact(job.Id,"N",out id)||job.End<job.Start)throw new InvalidDataException("Invalid pending clip");jobs.Add(job);}catch(Exception ex){Disk.Log(root,"Skipped invalid pending clip: "+jobPath+" "+ex.Message);}}
                if(jobs.Count==0)jobs.Add(new ClipJob{Id=Guid.NewGuid().ToString("N"),Reason="Buffer recovered after interrupted recorder",Start=all.First().Start,End=all.Max(x=>x.End),Requested=info.Origin+all.Max(x=>x.End)});
                foreach(var job in jobs){Export(folder,all,job,s.ClipsFolder,true,s.MinimumFreeGB);recovered++;}
                info.Clean=true;Disk.Json(infoPath,info);
            }
            if(info.Clean){foreach(string p in Directory.GetFiles(folder)){string n=Path.GetFileName(p);if(n.EndsWith(".frag")||n.EndsWith(".frag.json")||n.EndsWith(".job.json")||n=="init.mp4"||n.EndsWith(".tmp"))File.Delete(p);}}
        }return recovered;
    }
}
}
