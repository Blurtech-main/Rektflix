using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
namespace ForeverRecorder {
public sealed class NativeCapture : IDisposable {
    [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int WriteCallback(IntPtr p,int n);
    [DllImport("Rektflix.Native.dll",CallingConvention=CallingConvention.StdCall)] static extern void RFStop();
    [DllImport("Rektflix.Native.dll",CallingConvention=CallingConvention.StdCall,CharSet=CharSet.Unicode)] static extern int RFRecord(IntPtr window,int w,int h,int fps,int bitrate,int hardware,int system,int mic,int cursor,int synthetic,WriteCallback cb,StringBuilder error,int errorCount);
    WriteCallback callback;Thread thread;public string Error;public readonly ManualResetEventSlim Complete=new ManualResetEventSlim(false);
    public void Start(Stream output,IntPtr handle,Settings s,bool synthetic){
        callback=(p,n)=>{try{byte[] b=new byte[n];Marshal.Copy(p,b,0,n);output.Write(b,0,n);return 0;}catch(Exception ex){Error=ex.ToString();return unchecked((int)0x80004005);}};
        thread=new Thread(()=>{try{var error=new StringBuilder(2048);int hr=RFRecord(handle,s.Width,s.Height,s.Fps,s.BitrateMbps*1000000,s.HardwareEncoder?1:0,s.SystemAudio?1:0,s.Microphone?1:0,s.Cursor?1:0,synthetic?1:0,callback,error,2048);if(hr<0&&Error==null)Error=error.ToString();}catch(Exception ex){Error=ex.ToString();}finally{Complete.Set();}}){IsBackground=true,Name="Windows capture and encoding"};thread.Start();
    }
    public void Stop(){RFStop();}public void Dispose(){Stop();if(thread!=null)thread.Join(3000);GC.KeepAlive(callback);}
}
}
