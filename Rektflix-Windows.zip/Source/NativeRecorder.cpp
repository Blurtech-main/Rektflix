// Rektflix native capture: Windows Graphics Capture, WASAPI and Media Foundation.
// No game injection, input automation, network calls or third-party codec runtime.
#define NOMINMAX
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#include <codecapi.h>
#include <strmif.h>
#include <mmdeviceapi.h>
#include <audioclient.h>
#include <windows.graphics.capture.interop.h>
#include <windows.graphics.directx.direct3d11.interop.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Graphics.Capture.h>
#include <winrt/Windows.Graphics.DirectX.h>
#include <winrt/Windows.Graphics.DirectX.Direct3D11.h>
#include <wrl/client.h>
#include <atomic>
#include <vector>
#include <deque>
#include <string>
#include <algorithm>
#include <cmath>
#include <chrono>
#include <thread>
#include <mutex>
using Microsoft::WRL::ComPtr;
using namespace winrt::Windows::Graphics::Capture;
using namespace winrt::Windows::Graphics::DirectX;
using namespace winrt::Windows::Graphics::DirectX::Direct3D11;
using WriteFn = HRESULT (__stdcall *)(const BYTE*,int);
static std::atomic<bool> stopRequested{false};
struct Failure { HRESULT code; std::wstring stage; };
static void check(HRESULT hr,const wchar_t* stage){if(FAILED(hr))throw Failure{hr,stage};}
class OutputStream final : public IStream {
 std::atomic<ULONG> refs{1}; WriteFn callback;ULONGLONG position=0,length=0;
public:
 explicit OutputStream(WriteFn cb):callback(cb){}
 HRESULT STDMETHODCALLTYPE QueryInterface(REFIID id,void** p) override {if(!p)return E_POINTER;*p=nullptr;if(id==__uuidof(IUnknown)||id==__uuidof(IStream)||id==__uuidof(ISequentialStream)){*p=this;AddRef();return S_OK;}return E_NOINTERFACE;}
 ULONG STDMETHODCALLTYPE AddRef()override{return ++refs;}ULONG STDMETHODCALLTYPE Release()override{ULONG n=--refs;if(!n)delete this;return n;}
 HRESULT STDMETHODCALLTYPE Read(void*,ULONG,ULONG*)override{return STG_E_ACCESSDENIED;}
 HRESULT STDMETHODCALLTYPE Write(const void* p,ULONG n,ULONG* written)override{ULONG skip=(ULONG)std::min<ULONGLONG>(n,length-position);HRESULT hr=skip==n?S_OK:callback((const BYTE*)p+skip,(int)(n-skip));if(SUCCEEDED(hr)){position+=n;length=std::max(length,position);if(written)*written=n;}else if(written)*written=0;return hr;}
 HRESULT STDMETHODCALLTYPE Seek(LARGE_INTEGER off,DWORD origin,ULARGE_INTEGER* out)override{LONGLONG target=(origin==STREAM_SEEK_SET?0:origin==STREAM_SEEK_CUR?position:length)+off.QuadPart;if(target<0||(ULONGLONG)target>length)return STG_E_INVALIDFUNCTION;position=(ULONGLONG)target;if(out)out->QuadPart=position;return S_OK;}
 HRESULT STDMETHODCALLTYPE SetSize(ULARGE_INTEGER)override{return S_OK;}
 HRESULT STDMETHODCALLTYPE CopyTo(IStream*,ULARGE_INTEGER,ULARGE_INTEGER*,ULARGE_INTEGER*)override{return E_NOTIMPL;}
 HRESULT STDMETHODCALLTYPE Commit(DWORD)override{return S_OK;}HRESULT STDMETHODCALLTYPE Revert()override{return E_NOTIMPL;}
 HRESULT STDMETHODCALLTYPE LockRegion(ULARGE_INTEGER,ULARGE_INTEGER,DWORD)override{return E_NOTIMPL;}
 HRESULT STDMETHODCALLTYPE UnlockRegion(ULARGE_INTEGER,ULARGE_INTEGER,DWORD)override{return E_NOTIMPL;}
 HRESULT STDMETHODCALLTYPE Stat(STATSTG* s,DWORD)override{if(!s)return E_POINTER;ZeroMemory(s,sizeof(*s));s->type=STGTY_STREAM;s->grfMode=STGM_WRITE;s->cbSize.QuadPart=length;return S_OK;}
 HRESULT STDMETHODCALLTYPE Clone(IStream**)override{return E_NOTIMPL;}
};
struct Audio {
 ComPtr<IAudioClient> client;ComPtr<IAudioCaptureClient> capture;WAVEFORMATEX* format=nullptr;std::deque<float> samples;bool floating=false;
 ~Audio(){if(client)client->Stop();if(format)CoTaskMemFree(format);}
 void Open(bool microphone){
  ComPtr<IMMDeviceEnumerator> e;check(CoCreateInstance(__uuidof(MMDeviceEnumerator),nullptr,CLSCTX_ALL,IID_PPV_ARGS(&e)),L"Audio device enumerator");
  ComPtr<IMMDevice> device;check(e->GetDefaultAudioEndpoint(microphone?eCapture:eRender,eConsole,&device),microphone?L"No default microphone":L"No default playback device");
  check(device->Activate(__uuidof(IAudioClient),CLSCTX_ALL,nullptr,(void**)client.GetAddressOf()),L"Activate audio device");check(client->GetMixFormat(&format),L"Read audio format");
  floating=format->wFormatTag==WAVE_FORMAT_IEEE_FLOAT;
  if(format->wFormatTag==WAVE_FORMAT_EXTENSIBLE)floating=((WAVEFORMATEXTENSIBLE*)format)->SubFormat==KSDATAFORMAT_SUBTYPE_IEEE_FLOAT;
  if(!(floating&&format->wBitsPerSample==32)&&format->wBitsPerSample!=16)throw Failure{E_NOTIMPL,L"Audio device format must be float32 or PCM16"};
  check(client->Initialize(AUDCLNT_SHAREMODE_SHARED,microphone?0:AUDCLNT_STREAMFLAGS_LOOPBACK,1000000,0,format,nullptr),L"Initialize WASAPI capture");
  check(client->GetService(IID_PPV_ARGS(&capture)),L"Get audio capture service");check(client->Start(),L"Start audio capture");
 }
 void Pump(){UINT32 next=0;check(capture->GetNextPacketSize(&next),L"Audio device disconnected");
  while(next){BYTE* bytes=nullptr;UINT32 frames=0;DWORD flags=0;check(capture->GetBuffer(&bytes,&frames,&flags,nullptr,nullptr),L"Read audio packet");
   int count=(int)std::llround((double)frames*48000/format->nSamplesPerSec);
   for(int i=0;i<count;i++){double src=(double)i*format->nSamplesPerSec/48000;UINT32 a=std::min((UINT32)src,frames-1),b=std::min(a+1,frames-1);float part=(float)(src-a);
    for(int ch=0;ch<2;ch++){float v=0;if(!(flags&AUDCLNT_BUFFERFLAGS_SILENT)){int c=std::min(ch,(int)format->nChannels-1);int ia=a*format->nChannels+c,ib=b*format->nChannels+c;float x=floating?((float*)bytes)[ia]:((short*)bytes)[ia]/32768.0f;float y=floating?((float*)bytes)[ib]:((short*)bytes)[ib]/32768.0f;v=x+(y-x)*part;}samples.push_back(v);}
   }
   check(capture->ReleaseBuffer(frames),L"Release audio packet");if(samples.size()>48000*4)throw Failure{E_FAIL,L"Audio capture fell behind; restart recording"};check(capture->GetNextPacketSize(&next),L"Audio device disconnected");
  }
 }
 float Pop(){if(samples.empty())return 0;float v=samples.front();samples.pop_front();return v;}
};
static void sample(IMFSinkWriter* writer,DWORD index,const BYTE* bytes,DWORD count,LONGLONG time,LONGLONG duration){
 ComPtr<IMFMediaBuffer> buffer;check(MFCreateMemoryBuffer(count,&buffer),L"Allocate media buffer");BYTE* dest=nullptr;check(buffer->Lock(&dest,nullptr,nullptr),L"Lock media buffer");memcpy(dest,bytes,count);buffer->Unlock();buffer->SetCurrentLength(count);
 ComPtr<IMFSample> s;check(MFCreateSample(&s),L"Create media sample");s->AddBuffer(buffer.Get());s->SetSampleTime(time);s->SetSampleDuration(duration);check(writer->WriteSample(index,s.Get()),L"Encode media sample");
}
static BYTE clip(int x){return (BYTE)std::max(0,std::min(255,x));}
static void convert(const BYTE* bgra,BYTE* nv12,int w,int h){
 BYTE* uv=nv12+w*h;
 for(int y=0;y<h;y++)for(int x=0;x<w;x++){const BYTE* p=bgra+(y*w+x)*4;int b=p[0],g=p[1],r=p[2];nv12[y*w+x]=clip(16+((47*r+157*g+16*b+128)>>8));}
 for(int y=0;y<h;y+=2)for(int x=0;x<w;x+=2){int r=0,g=0,b=0;for(int dy=0;dy<2;dy++)for(int dx=0;dx<2;dx++){const BYTE* p=bgra+((y+dy)*w+x+dx)*4;b+=p[0];g+=p[1];r+=p[2];}r/=4;g/=4;b/=4;uv[(y/2)*w+x]=clip(128+((-26*r-87*g+112*b+128)>>8));uv[(y/2)*w+x+1]=clip(128+((112*r-102*g-10*b+128)>>8));}
}
extern "C" __declspec(dllexport) void __stdcall RFStop(){stopRequested=true;}
extern "C" __declspec(dllexport) HRESULT __stdcall RFRecord(HWND window,int width,int height,int fps,int bitrate,int hardware,int systemAudio,int microphone,int cursor,int synthetic,WriteFn output,wchar_t* error,int errorCount){
 stopRequested=false;HRESULT result=S_OK;bool com=false,mf=false;HDC dc=nullptr;HBITMAP bitmap=nullptr;HGDIOBJ old=nullptr;
 try {
  check(CoInitializeEx(nullptr,COINIT_MULTITHREADED),L"Initialize COM");com=true;check(MFStartup(MF_VERSION),L"Start Windows Media Foundation");mf=true;
  ComPtr<ID3D11Device> device;ComPtr<ID3D11DeviceContext> context;D3D_FEATURE_LEVEL level;
  GraphicsCaptureItem item{nullptr};Direct3D11CaptureFramePool pool{nullptr};GraphicsCaptureSession session{nullptr};
  std::mutex frameMutex;std::vector<BYTE> source;int sourceW=width,sourceH=height;bool gdiFallback=false;std::atomic<bool> gotFrame{false};std::atomic<HRESULT> captureError{S_OK};winrt::event_token frameToken{};
  struct CaptureClose {Direct3D11CaptureFramePool& p;GraphicsCaptureSession& s;winrt::event_token& token;~CaptureClose(){try{if(p&&token.value)p.FrameArrived(token);if(s)s.Close();if(p)p.Close();}catch(...){}}} cleanup{pool,session,frameToken};
  if(!synthetic){
   if(!IsWindow(window))throw Failure{E_INVALIDARG,L"WoW window is no longer available"};
   try{check(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,D3D11_CREATE_DEVICE_BGRA_SUPPORT,nullptr,0,D3D11_SDK_VERSION,&device,&level,&context),L"Create graphics capture device");
   ComPtr<IDXGIDevice> dxgi;check(device.As(&dxgi),L"Get DXGI device");winrt::com_ptr<IInspectable> inspect;
   check(CreateDirect3D11DeviceFromDXGIDevice(dxgi.Get(),inspect.put()),L"Create WinRT graphics device");auto direct=inspect.as<IDirect3DDevice>();
   auto interop=winrt::get_activation_factory<GraphicsCaptureItem,IGraphicsCaptureItemInterop>();check(interop->CreateForWindow(window,winrt::guid_of<::ABI::Windows::Graphics::Capture::IGraphicsCaptureItem>(),reinterpret_cast<void**>(winrt::put_abi(item))),L"Capture WoW window (restore if minimized)");
   pool=Direct3D11CaptureFramePool::CreateFreeThreaded(direct,DirectXPixelFormat::B8G8R8A8UIntNormalized,2,item.Size());session=pool.CreateCaptureSession(item);
   // The cursor property is optional on older Windows 10 versions; do not call border APIs.
   try{session.IsCursorCaptureEnabled(cursor!=0);}catch(winrt::hresult_error const&){}
   frameToken=pool.FrameArrived([&,direct](auto const& sender,auto const&){try{
    auto frame=sender.TryGetNextFrame();if(!frame)return;auto access=frame.Surface().as<::Windows::Graphics::DirectX::Direct3D11::IDirect3DDxgiInterfaceAccess>();ComPtr<ID3D11Texture2D> texture;
    check(access->GetInterface(IID_PPV_ARGS(&texture)),L"Read captured texture");D3D11_TEXTURE2D_DESC desc;texture->GetDesc(&desc);
    int w=std::min((int)desc.Width,frame.ContentSize().Width),h=std::min((int)desc.Height,frame.ContentSize().Height);if(w<=0||h<=0)return;
    desc.Usage=D3D11_USAGE_STAGING;desc.BindFlags=0;desc.CPUAccessFlags=D3D11_CPU_ACCESS_READ;desc.MiscFlags=0;ComPtr<ID3D11Texture2D> staging;check(device->CreateTexture2D(&desc,nullptr,&staging),L"Create frame staging texture");
    context->CopyResource(staging.Get(),texture.Get());D3D11_MAPPED_SUBRESOURCE map;check(context->Map(staging.Get(),0,D3D11_MAP_READ,0,&map),L"Map captured frame");
    {std::lock_guard<std::mutex> lock(frameMutex);source.resize((size_t)w*h*4);for(int y=0;y<h;y++)memcpy(source.data()+(size_t)y*w*4,(BYTE*)map.pData+y*map.RowPitch,w*4);sourceW=w;sourceH=h;gotFrame=true;}
    context->Unmap(staging.Get(),0);auto contentSize=frame.ContentSize();bool resized=contentSize.Width!=(int)desc.Width||contentSize.Height!=(int)desc.Height;frame.Close();if(resized&&contentSize.Width>0&&contentSize.Height>0)sender.Recreate(direct,DirectXPixelFormat::B8G8R8A8UIntNormalized,2,contentSize);
   }catch(Failure const& e){captureError=e.code;}catch(...){captureError=E_FAIL;}});
   session.StartCapture();
   }catch(Failure const&){try{if(pool&&frameToken.value)pool.FrameArrived(frameToken);if(session)session.Close();if(pool)pool.Close();}catch(...){}session=nullptr;pool=nullptr;frameToken={};captureError=S_OK;gdiFallback=true;gotFrame=true;
   }catch(winrt::hresult_error const&){try{if(pool&&frameToken.value)pool.FrameArrived(frameToken);if(session)session.Close();if(pool)pool.Close();}catch(...){}session=nullptr;pool=nullptr;frameToken={};captureError=S_OK;gdiFallback=true;gotFrame=true;}
  }else{source.resize((size_t)width*height*4);gotFrame=true;}
  ComPtr<IMFMediaType> videoOut;check(MFCreateMediaType(&videoOut),L"Create video type");videoOut->SetGUID(MF_MT_MAJOR_TYPE,MFMediaType_Video);videoOut->SetGUID(MF_MT_SUBTYPE,MFVideoFormat_H264);videoOut->SetUINT32(MF_MT_AVG_BITRATE,bitrate);videoOut->SetUINT32(MF_MT_INTERLACE_MODE,MFVideoInterlace_Progressive);videoOut->SetUINT32(MF_MT_MPEG2_PROFILE,77);MFSetAttributeSize(videoOut.Get(),MF_MT_FRAME_SIZE,width,height);MFSetAttributeRatio(videoOut.Get(),MF_MT_FRAME_RATE,fps,1);MFSetAttributeRatio(videoOut.Get(),MF_MT_PIXEL_ASPECT_RATIO,1,1);
  ComPtr<IMFMediaType> audioOut;if(systemAudio||microphone){MFCreateMediaType(&audioOut);audioOut->SetGUID(MF_MT_MAJOR_TYPE,MFMediaType_Audio);audioOut->SetGUID(MF_MT_SUBTYPE,MFAudioFormat_AAC);audioOut->SetUINT32(MF_MT_AUDIO_NUM_CHANNELS,2);audioOut->SetUINT32(MF_MT_AUDIO_SAMPLES_PER_SECOND,48000);audioOut->SetUINT32(MF_MT_AUDIO_BITS_PER_SAMPLE,16);audioOut->SetUINT32(MF_MT_AUDIO_AVG_BYTES_PER_SECOND,24000);}
  ComPtr<IStream> stream;stream.Attach(new OutputStream(output));ComPtr<IMFByteStream> byteStream;check(MFCreateMFByteStreamOnStream(stream.Get(),&byteStream),L"Create fragment byte stream");
  ComPtr<IMFMediaSink> sink;check(MFCreateFMPEG4MediaSink(byteStream.Get(),videoOut.Get(),audioOut.Get(),&sink),L"Create fragmented MP4 sink");
  ComPtr<IMFAttributes> attrs;MFCreateAttributes(&attrs,3);attrs->SetUINT32(MF_READWRITE_ENABLE_HARDWARE_TRANSFORMS,hardware?TRUE:FALSE);attrs->SetUINT32(MF_SINK_WRITER_DISABLE_THROTTLING,TRUE);
  ComPtr<IMFSinkWriter> writer;check(MFCreateSinkWriterFromMediaSink(sink.Get(),attrs.Get(),&writer),L"Create H.264 sink writer");
  ComPtr<IMFMediaType> videoIn;MFCreateMediaType(&videoIn);videoOut->CopyAllItems(videoIn.Get());videoIn->SetGUID(MF_MT_SUBTYPE,MFVideoFormat_NV12);videoIn->DeleteItem(MF_MT_MPEG2_PROFILE);check(writer->SetInputMediaType(0,videoIn.Get(),nullptr),L"Initialize H.264 encoder");
  if(audioOut){ComPtr<IMFMediaType> audioIn;MFCreateMediaType(&audioIn);audioIn->SetGUID(MF_MT_MAJOR_TYPE,MFMediaType_Audio);audioIn->SetGUID(MF_MT_SUBTYPE,MFAudioFormat_PCM);audioIn->SetUINT32(MF_MT_AUDIO_NUM_CHANNELS,2);audioIn->SetUINT32(MF_MT_AUDIO_SAMPLES_PER_SECOND,48000);audioIn->SetUINT32(MF_MT_AUDIO_BITS_PER_SAMPLE,16);audioIn->SetUINT32(MF_MT_AUDIO_BLOCK_ALIGNMENT,4);audioIn->SetUINT32(MF_MT_AUDIO_AVG_BYTES_PER_SECOND,192000);check(writer->SetInputMediaType(1,audioIn.Get(),nullptr),L"Initialize AAC encoder");}
  check(writer->BeginWriting(),L"Start encoding");Audio system,mic;if(systemAudio)system.Open(false);if(microphone)mic.Open(true);
  BITMAPINFO bi{};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bi.bmiHeader.biWidth=width;bi.bmiHeader.biHeight=-height;bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;bi.bmiHeader.biCompression=BI_RGB;
  BYTE* scaled=nullptr;dc=CreateCompatibleDC(nullptr);bitmap=CreateDIBSection(dc,&bi,DIB_RGB_COLORS,(void**)&scaled,nullptr,0);if(!dc||!bitmap)throw Failure{E_OUTOFMEMORY,L"Allocate scaling surface"};old=SelectObject(dc,bitmap);SetStretchBltMode(dc,HALFTONE);
  std::vector<BYTE> nv12((size_t)width*height*3/2);long long frameNumber=0,audioFrames=0;
  auto start=std::chrono::steady_clock::now();auto waitStart=start;
  while(!stopRequested){
   check(captureError.load(),L"Window capture failed");auto now=std::chrono::steady_clock::now();double elapsed=std::chrono::duration<double>(now-start).count();
   if(!gotFrame){if(std::chrono::duration<double>(now-waitStart).count()>10)throw Failure{E_FAIL,L"No window frames received"};std::this_thread::sleep_for(std::chrono::milliseconds(5));start=std::chrono::steady_clock::now();continue;}
   double next=(double)frameNumber/fps;if(elapsed<next){std::this_thread::sleep_for(std::chrono::milliseconds(1));continue;}
   if(elapsed-next>5)throw Failure{E_FAIL,L"Encoder cannot keep up. Reduce resolution or frame rate."};
   {std::lock_guard<std::mutex> lock(frameMutex);
    if(synthetic)for(int y=0;y<height;y++)for(int x=0;x<width;x++){size_t i=((size_t)y*width+x)*4;source[i]=(BYTE)(x+frameNumber*3);source[i+1]=(BYTE)(y+frameNumber);source[i+2]=(BYTE)(frameNumber*5);source[i+3]=255;}
    if(gdiFallback){RECT r{};POINT origin{};if(!GetClientRect(window,&r)||!ClientToScreen(window,&origin)||r.right<=0||r.bottom<=0)throw Failure{E_FAIL,L"Read WoW window geometry"};
     int sw=r.right,sh=r.bottom;double scale=std::min((double)width/sw,(double)height/sh);int w=(int)(sw*scale),h=(int)(sh*scale),ox=(width-w)/2,oy=(height-h)/2;HDC screen=GetDC(nullptr);if(!screen)throw Failure{E_FAIL,L"Open desktop capture"};PatBlt(dc,0,0,width,height,BLACKNESS);BOOL copied=StretchBlt(dc,ox,oy,w,h,screen,origin.x,origin.y,sw,sh,SRCCOPY|CAPTUREBLT);
     if(cursor){CURSORINFO ci{sizeof(ci)};if(GetCursorInfo(&ci)&&(ci.flags&CURSOR_SHOWING)&&ci.ptScreenPos.x>=origin.x&&ci.ptScreenPos.x<origin.x+sw&&ci.ptScreenPos.y>=origin.y&&ci.ptScreenPos.y<origin.y+sh){ICONINFO ii{};int hotX=0,hotY=0;if(GetIconInfo(ci.hCursor,&ii)){hotX=(int)ii.xHotspot;hotY=(int)ii.yHotspot;if(ii.hbmMask)DeleteObject(ii.hbmMask);if(ii.hbmColor)DeleteObject(ii.hbmColor);}int cx=ox+(int)((ci.ptScreenPos.x-origin.x-hotX)*scale),cy=oy+(int)((ci.ptScreenPos.y-origin.y-hotY)*scale);DrawIconEx(dc,cx,cy,ci.hCursor,(int)(32*scale),(int)(32*scale),0,nullptr,DI_NORMAL);}}
     ReleaseDC(nullptr,screen);if(!copied)throw Failure{HRESULT_FROM_WIN32(GetLastError()),L"Copy WoW window pixels"};GdiFlush();
    }else{BITMAPINFO src=bi;src.bmiHeader.biWidth=sourceW;src.bmiHeader.biHeight=-sourceH;double scale=std::min((double)width/sourceW,(double)height/sourceH);int w=(int)(sourceW*scale),h=(int)(sourceH*scale);PatBlt(dc,0,0,width,height,BLACKNESS);
     StretchDIBits(dc,(width-w)/2,(height-h)/2,w,h,0,0,sourceW,sourceH,source.data(),&src,DIB_RGB_COLORS,SRCCOPY);GdiFlush();}
   }
   convert(scaled,nv12.data(),width,height);LONGLONG t=frameNumber*10000000/fps,nextT=(frameNumber+1)*10000000/fps;sample(writer.Get(),0,nv12.data(),(DWORD)nv12.size(),t,nextT-t);
   if(audioOut){if(systemAudio)system.Pump();if(microphone)mic.Pump();long long until=(frameNumber+1)*48000/fps;int count=(int)(until-audioFrames);std::vector<short> audio(count*2);for(int i=0;i<count*2;i++){float v=(systemAudio?system.Pop():0)+(microphone?mic.Pop():0);audio[i]=(short)std::max(-32768.0f,std::min(32767.0f,v*32767));}sample(writer.Get(),1,(BYTE*)audio.data(),(DWORD)audio.size()*2,audioFrames*10000000/48000,(until*10000000/48000)-(audioFrames*10000000/48000));audioFrames=until;}
   frameNumber++;
  }
  if(session){session.Close();pool.FrameArrived(frameToken);pool.Close();session=nullptr;pool=nullptr;}
  check(writer->Finalize(),L"Finalize recording");sink->Shutdown();
 }catch(Failure const& e){result=e.code;swprintf_s(error,errorCount,L"%s (0x%08X)",e.stage.c_str(),(unsigned)e.code);}catch(winrt::hresult_error const& e){result=e.code();wcsncpy_s(error,errorCount,e.message().c_str(),_TRUNCATE);}catch(...){result=E_FAIL;wcsncpy_s(error,errorCount,L"Unexpected native recorder error",_TRUNCATE);}
 if(old&&dc)SelectObject(dc,old);if(bitmap)DeleteObject(bitmap);if(dc)DeleteDC(dc);if(mf)MFShutdown();if(com)CoUninitialize();return result;
}
