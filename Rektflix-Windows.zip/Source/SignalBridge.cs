using System;
using System.Drawing;
using System.Runtime.InteropServices;
namespace ForeverRecorder {
public sealed class SignalBridge {
    [StructLayout(LayoutKind.Sequential)]struct Point{public int X,Y;}
    [DllImport("user32.dll")]static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")]static extern bool ClientToScreen(IntPtr h,ref Point p);
    int last=-1,candidate=-1;
    public static int Decode(Bitmap bitmap) {
        Color a=bitmap.GetPixel(2,4),b=bitmap.GetPixel(6,4);
        if(a.R<180||a.G>70||a.B<65||a.B>195||b.R>70||b.G<180||b.B<65||b.B>195)return -1;
        int packed=0;for(int i=0;i<24;i++){var c=bitmap.GetPixel((i+2)*4+2,4);bool white=c.R>180&&c.G>180&&c.B>180,black=c.R<70&&c.G<70&&c.B<70;if(!white&&!black)return -1;if(white)packed|=1<<i;}
        int code=packed&15,seq=(packed>>4)&255,arg=(packed>>12)&255,check=(packed>>20)&15;
        if(code<1||code>10||check!=(code+seq+arg)%16)return -1;return packed;
    }
    public int Poll(IntPtr window){
        if(GetForegroundWindow()!=window||!Native.IsWindowVisible(window))return 0;
        var p=new Point{X=8,Y=8};if(!ClientToScreen(window,ref p))return 0;
        using(var b=new Bitmap(112,8)){using(var g=Graphics.FromImage(b))g.CopyFromScreen(p.X,p.Y,0,0,b.Size);int value=Decode(b);
            if(value<0){candidate=-1;last=-1;return 0;}if(value!=candidate){candidate=value;return 0;}
            if(value==last)return 0;last=value;return value&15;}
    }
}
}
