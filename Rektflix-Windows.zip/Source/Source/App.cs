using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
namespace ForeverRecorder {
public sealed class RainbowTextButton : Button {
    static readonly Color[] Rainbow={Color.FromArgb(240,65,65),Color.FromArgb(247,145,45),Color.FromArgb(247,213,61),Color.FromArgb(91,207,115),Color.FromArgb(75,150,245),Color.FromArgb(91,78,181),Color.FromArgb(176,91,220)};
    bool hot,down;
    public RainbowTextButton(){SetStyle(ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.UserPaint,true);}
    protected override void OnMouseEnter(EventArgs e){hot=true;Invalidate();base.OnMouseEnter(e);}protected override void OnMouseLeave(EventArgs e){hot=false;down=false;Invalidate();base.OnMouseLeave(e);}protected override void OnMouseDown(MouseEventArgs e){down=true;Invalidate();base.OnMouseDown(e);}protected override void OnMouseUp(MouseEventArgs e){down=false;Invalidate();base.OnMouseUp(e);}
    protected override void OnPaint(PaintEventArgs e){Color back=down?Color.FromArgb(34,35,44):hot?Color.FromArgb(50,51,63):BackColor;using(var b=new SolidBrush(back))e.Graphics.FillRectangle(b,ClientRectangle);using(var p=new Pen(FlatAppearance.BorderColor.IsEmpty?Color.FromArgb(70,72,86):FlatAppearance.BorderColor))e.Graphics.DrawRectangle(p,0,0,Width-1,Height-1);var flags=TextFormatFlags.NoPadding|TextFormatFlags.SingleLine|TextFormatFlags.VerticalCenter;var widths=Text.Select(ch=>TextRenderer.MeasureText(e.Graphics,ch.ToString(),Font,new Size(int.MaxValue,Height),flags).Width).ToArray();int x=(Width-widths.Sum())/2,color=0;for(int i=0;i<Text.Length;i++){char ch=Text[i];Color ink=char.IsWhiteSpace(ch)?ForeColor:Rainbow[color++%Rainbow.Length];TextRenderer.DrawText(e.Graphics,ch.ToString(),Font,new Rectangle(x,0,widths[i]+2,Height),Enabled?ink:SystemColors.GrayText,flags);x+=widths[i];}if(Focused&&ShowFocusCues)ControlPaint.DrawFocusRectangle(e.Graphics,new Rectangle(3,3,Width-7,Height-7));}
}
public sealed class DriveSpaceBars : Control {
    readonly ToolTip tip=new ToolTip();
    public DriveSpaceBars(){SetStyle(ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer|ControlStyles.UserPaint,true);AccessibleName="Drive space used and remaining";}
    static DriveInfo[] Drives(){try{return DriveInfo.GetDrives().Where(x=>x.IsReady&&x.DriveType!=DriveType.CDRom).Take(3).ToArray();}catch{return new DriveInfo[0];}}
    static string FormatBytes(long n){return n>=1024L*1024*1024?(n/1024d/1024/1024).ToString("0.0")+" GB":(n/1024d/1024).ToString("0")+" MB";}
    protected override void OnHandleCreated(EventArgs e){base.OnHandleCreated(e);var drives=Drives();tip.SetToolTip(this,drives.Length==0?"No ready drives":string.Join(Environment.NewLine,drives.Select(x=>x.Name+"  "+FormatBytes(x.TotalSize-x.AvailableFreeSpace)+" used, "+FormatBytes(x.AvailableFreeSpace)+" remaining")));}
    protected override void OnPaint(PaintEventArgs e){e.Graphics.Clear(Color.FromArgb(29,30,39));var drives=Drives();int count=Math.Max(1,drives.Length),gap=2,height=Math.Max(7,(Height-gap*(count+1))/count);using(var labelFont=new Font("Segoe UI",6.5f,FontStyle.Bold)){for(int i=0;i<drives.Length;i++){int y=gap+i*(height+gap),w=Width-6;double used=drives[i].TotalSize<=0?0:1-drives[i].AvailableFreeSpace/(double)drives[i].TotalSize;using(var free=new SolidBrush(Color.FromArgb(74,190,145)))e.Graphics.FillRectangle(free,3,y,w,height);using(var taken=new SolidBrush(Color.FromArgb(242,145,48)))e.Graphics.FillRectangle(taken,3,y,(int)Math.Round(w*used),height);using(var border=new Pen(Color.FromArgb(92,94,108)))e.Graphics.DrawRectangle(border,2,y-1,w+1,height+1);string text=drives[i].Name.TrimEnd('\\')+" "+Math.Round(used*100).ToString("0")+"%";TextRenderer.DrawText(e.Graphics,text,labelFont,new Rectangle(5,y-1,w-3,height+2),Color.White,TextFormatFlags.NoPadding|TextFormatFlags.VerticalCenter|TextFormatFlags.SingleLine);}}using(var outline=new Pen(Color.FromArgb(70,72,86)))e.Graphics.DrawRectangle(outline,0,0,Width-1,Height-1);}
    protected override void Dispose(bool disposing){if(disposing)tip.Dispose();base.Dispose(disposing);}
}
static class Program {
    public static string Exe {get{return Application.ExecutablePath;}}
    public static string Quote(string s){return "\""+s.Replace("\"","")+"\"";}
    [STAThread] static int Main(string[] args){
        if(args.Length>0&&args[0]=="--worker")return Engine.Run(args[1],long.Parse(args[2]),int.Parse(args[3]),args.Length>4&&args[4]=="synthetic"?"synthetic":null,args.Length>5?int.Parse(args[5]):0);
        if(args.Length>0&&args[0]=="--self-test")return Tests.Run(args.Length>1?args[1]:Path.Combine(Path.GetTempPath(),"Rektflix-tests"));
        if(args.Length>0&&args[0]=="--space-test")return SpaceTests.RunStandalone(args.Length>1?args[1]:Path.Combine(Path.GetTempPath(),"Rektflix-space-tests"));
        if(args.Length>1&&args[0]=="--resume-space"){
            string manifest=Path.GetFullPath(args[1]);string status=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"space-resume-status.json");
            try{
                var journal=Disk.Read<MoveJournal>(manifest);DateTime last=DateTime.MinValue;
                var result=SpaceMover.Move(new SpaceCollection[0],Path.GetDirectoryName(journal.Destination),journal.Vault,CancellationToken.None,p=>{
                    if((DateTime.UtcNow-last).TotalSeconds<1)return;last=DateTime.UtcNow;
                    Disk.Json(status,new{State="Moving",p.BytesDone,p.BytesTotal,p.Completed,p.Total,p.File,p.BytesPerSecond});
                },manifest);
                Disk.Json(status,new{State=result.Cancelled?"Cancelled":result.Errors.Count>0?"Completed with errors":"Completed",result.MovedBytes,Errors=result.Errors});
                if(!result.Cancelled&&result.Errors.Count==0){string pointer=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Rektflix","pending-space-move.txt");if(File.Exists(pointer)&&string.Equals(File.ReadAllText(pointer).Trim(),manifest,StringComparison.OrdinalIgnoreCase))File.Delete(pointer);}
                return result.Cancelled?3:result.Errors.Count>0?2:0;
            }catch(Exception ex){Disk.Json(status,new{State="Failed",Error=ex.ToString()});return 2;}
        }
        if(args.Length>0&&args[0]=="--space-preview"){Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new SpaceForm(args[1],true));return 0;}
        if(args.Length>1&&args[0]=="--install-addon"){try{Wow.Install(args[1]);return 0;}catch(Exception ex){MessageBox.Show(ex.Message,"Rektflix addon install");return 2;}}
        Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
        bool previewRun=args.Length>0&&args[0]=="--preview";bool created;using(var mutex=new Mutex(true,previewRun?"Local\\Rektflix-App-Preview":"Local\\Rektflix-App",out created)){if(!created){MessageBox.Show("Rektflix is already running. Open it from the system tray.","Rektflix");return 0;}
            string root=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Rektflix");
            bool preview=args.Length>0&&args[0]=="--preview";if(preview)root=args[1];
            try{Application.Run(new MainForm(root,preview));return 0;}catch(Exception ex){Disk.Log(root,ex.ToString());MessageBox.Show(ex.Message,"Rektflix needs attention",MessageBoxButtons.OK,MessageBoxIcon.Error);return 2;}}
    }
}
public sealed class MainForm : Form {
    readonly string root;readonly bool preview;Settings settings;Process worker;double stoppedAt,nextLaunch;bool armed,quitting,closeAllowed;int failures;
    readonly System.Windows.Forms.Timer timer=new System.Windows.Forms.Timer{Interval=500};readonly Label state=new Label(),detail=new Label(),banner=new Label();readonly Button arm=new Button();
    readonly Dictionary<string,Control> inputs=new Dictionary<string,Control>();readonly NotifyIcon tray=new NotifyIcon();Form compact;Label compactState;
    readonly List<Button> quickButtons=new List<Button>();double launchedAt;
    readonly Color background=Color.FromArgb(17,18,24),card=Color.FromArgb(29,30,39),accent=Color.FromArgb(244,47,82),muted=Color.FromArgb(178,180,192);readonly Font stateNormalFont=new Font("Segoe UI",14,FontStyle.Bold),stateWaitingFont=new Font("Segoe UI",12.6f,FontStyle.Bold);
    double importedAt;string uiNote="";
    public MainForm(string data,bool isPreview){root=data;preview=isPreview;Directory.CreateDirectory(root);string path=Path.Combine(root,"settings.json");
        try{settings=File.Exists(path)?Disk.Read<Settings>(path):new Settings();settings.Validate();}catch(Exception ex){settings=new Settings();uiNote="Settings could not load; defaults restored. "+ex.Message;Disk.Log(root,ex.ToString());}
        if(string.IsNullOrEmpty(settings.WowFolder))settings.WowFolder=Wow.Discover().FirstOrDefault()??"";
        Disk.Json(path,settings);armed=settings.AutoStart&&!preview;
        Text="Rektflix — 'n kill.";ClientSize=new Size(920,720);MinimumSize=new Size(800,600);BackColor=background;ForeColor=Color.White;Font=new Font("Segoe UI",10);StartPosition=FormStartPosition.CenterScreen;Icon=SystemIcons.Application;
        var header=new Panel{Dock=DockStyle.Top,Height=110,Padding=new Padding(24)};Controls.Add(header);
        header.Controls.Add(new Label{Text="REKTFLIX",Font=new Font("Segoe UI",26,FontStyle.Bold),ForeColor=accent,Location=new Point(22,15),Size=new Size(400,48)});
        header.Controls.Add(new Label{Text="'n kill.",ForeColor=muted,Location=new Point(25,65),Size=new Size(380,25)});
        var help=Button("Help manual",()=>ShowHelp());help.SetBounds(738,28,150,38);help.Anchor=AnchorStyles.Top|AnchorStyles.Right;header.Controls.Add(help);
        var bottom=new Panel{Dock=DockStyle.Bottom,Height=180,BackColor=card,Padding=new Padding(20)};Controls.Add(bottom);
        state.SetBounds(22,12,870,30);state.Font=stateNormalFont;state.Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right;bottom.Controls.Add(state);
        detail.SetBounds(22,45,870,40);detail.ForeColor=muted;bottom.Controls.Add(detail);
        var quick=new FlowLayoutPanel{Location=new Point(18,90),Size=new Size(885,40),Anchor=AnchorStyles.Left|AnchorStyles.Right|AnchorStyles.Top};bottom.Controls.Add(quick);
        for(int n=1;n<=3;n++){int code=n;var b=Button("",()=>Command(code));b.Tag=code;quickButtons.Add(b);quick.Controls.Add(b);}RefreshQuickButtons();
        quick.Controls.Add(Button("● Record",()=>Command(4)));quick.Controls.Add(Button("■ Stop clip",()=>Command(5)));
        arm.Text=armed?"Disarm":"Arm recorder";Style(arm);arm.Click+=(s,e)=>{armed=!armed;failures=0;if(!armed)StopWorker();};quick.Controls.Add(arm);
        var clips=Button("Open clips",()=>OpenFolder(settings.ClipsFolder));clips.SetBounds(22,137,130,30);bottom.Controls.Add(clips);
        var overlay=Button("Compact controls",()=>ShowCompact());overlay.SetBounds(165,137,170,30);bottom.Controls.Add(overlay);
        var diag=Button("Diagnostics",()=>OpenFolder(root));diag.SetBounds(350,137,130,30);bottom.Controls.Add(diag);
        var quit=Button("Quit Rektflix",()=>Quit());quit.SetBounds(748,137,140,30);quit.Anchor=AnchorStyles.Top|AnchorStyles.Right;bottom.Controls.Add(quit);
        var tabs=new TabControl{Dock=DockStyle.Fill,Padding=new Point(20,8)};Controls.Add(tabs);tabs.BringToFront();
        var setup=Page(tabs,"Game & setup");int y=20;
        TextField(setup,"WowFolder","WoW Classic / Forever folder",ref y);
        var browse=Button("Find game folder…",()=>{using(var d=new FolderBrowserDialog{Description="Select the Forever _classic_beta_ folder containing WowB.exe (or another supported WoW executable)"})if(d.ShowDialog()==DialogResult.OK)inputs["WowFolder"].Text=d.SelectedPath;});browse.SetBounds(20,y,190,34);setup.Controls.Add(browse);
        var install=Button("Install / update addon",()=>InstallAddon());install.SetBounds(225,y,210,34);setup.Controls.Add(install);y+=50;
        var space=RainbowButton("Free Up Space (optional)…",()=>ShowFreeSpace());space.SetBounds(20,y,230,34);setup.Controls.Add(space);var driveBars=new DriveSpaceBars();driveBars.SetBounds(258,y,66,34);setup.Controls.Add(driveBars);AddText(setup,"Review and safely move large collections - good when using a long buffer size",338,y+6,490,28);y+=48;
        AddText(setup,"Open this app before playing. It arms automatically and waits for the selected WoW window.\nFirst addon install: restart WoW, then use /rf or /rektflix.",20,y,820,72);
        y+=145;Check(setup,"AutoStart","Arm automatically when this app opens",ref y);Check(setup,"MinimizeToTray","Closing the window keeps recording in the system tray",ref y);
        banner.SetBounds(20,y+8,810,70);banner.ForeColor=Color.FromArgb(245,187,93);setup.Controls.Add(banner);
        var recording=Page(tabs,"Recording");y=20;
        Minutes(recording,"BufferSeconds","Rolling buffer length (minutes, max 300 / 5 hours)",1,300,ref y);Number(recording,"BeforeSeconds","Automatic clip: before event (seconds)",0,18000,ref y);Number(recording,"AfterSeconds","Automatic clip: after event (seconds)",0,300,ref y);
        Number(recording,"QuickOne","Save button 1: seconds",5,18000,ref y);Number(recording,"QuickTwo","Save button 2: seconds",5,18000,ref y);Number(recording,"QuickThree","Save button 3: seconds",5,18000,ref y);
        Number(recording,"Width","Video width (pixels)",640,3840,ref y);Number(recording,"Height","Video height (pixels)",360,2160,ref y);Number(recording,"Fps","Frame rate (FPS)",15,60,ref y);Number(recording,"BitrateMbps","Video quality / bitrate (Mbps)",2,50,ref y);
        Check(recording,"HardwareEncoder","Use hardware encoding when available",ref y);Check(recording,"SystemAudio","System audio — includes other apps on default playback device",ref y);Check(recording,"Microphone","Include default microphone",ref y);Check(recording,"Cursor","Include cursor (when supported by Windows)",ref y);
        AddText(recording,"Five hours at 8 Mbps is roughly 18 GB before audio. Raise the Storage buffer limit when needed.",20,y,810,45);
        var triggers=Page(tabs,"Triggers");y=20;
        Check(triggers,"MyPvpKills","My PvP killing blows",ref y);Check(triggers,"PartyPvpKills","Party members' PvP killing blows",ref y);Check(triggers,"MyDeath","My death",ref y);Check(triggers,"NearbyPlayerDeaths","Nearby player deaths",ref y);Check(triggers,"MyNpcKills","My creature kills",ref y);Check(triggers,"Interrupts","My interrupts",ref y);
        Check(triggers,"SpellCasts","Enable successful spell-cast ID triggers",ref y);TextField(triggers,"SpellIds","Successful spell-cast IDs (comma separated)",ref y);Check(triggers,"LootChatLogging","Enable watched item links in WoW chat log (stores chat locally)",ref y);TextField(triggers,"LootIds","Watched item IDs (loot or chat links; NOT drop confirmation)",ref y);
        var storage=Page(tabs,"Storage");y=20;TextField(storage,"ClipsFolder","Saved clips folder",ref y);Number(storage,"BufferLimitGB","Maximum buffer space (GB)",1,100,ref y);Number(storage,"MinimumFreeGB","Free disk reserve (GB)",1,100,ref y);
        AddText(storage,"The buffer is stored in your local app-data folder.\nSaved clips are never automatically deleted.\nCrash recovery preserves available completed fragments on the next recording start.\nA power failure can still lose the latest data; disk flushing is not a UPS.\n\nWoW combat/chat logs have their own storage usage and are not deleted by Rektflix.",20,y+10,810,170);
        var applyPanel=new Panel{Dock=DockStyle.Bottom,Height=50,BackColor=background};Controls.Add(applyPanel);tabs.BringToFront();var apply=Button("Apply recording settings",()=>Apply());apply.SetBounds(20,8,230,34);applyPanel.Controls.Add(apply);AddText(applyPanel,"Changes restart capture safely. Saved clips are retained.",270,14,600,30);
        tray.Icon=SystemIcons.Application;tray.Text="Rektflix";tray.Visible=!preview;var menu=new ContextMenuStrip();menu.Items.Add("Open Rektflix",null,(s,e)=>Restore());menu.Items.Add("Save recent clip",null,(s,e)=>Command(1));menu.Items.Add("Quit",null,(s,e)=>Quit());tray.ContextMenuStrip=menu;tray.DoubleClick+=(s,e)=>Restore();
        FormClosing+=(s,e)=>{if(closeAllowed)return;e.Cancel=true;if(settings.MinimizeToTray&&!quitting){Hide();tray.ShowBalloonTip(2500,"Rektflix","Still running. Use Quit from the tray to stop capture.",ToolTipIcon.Info);}else Quit();};FormClosed+=(s,e)=>{stateNormalFont.Dispose();stateWaitingFont.Dispose();};
        timer.Tick+=(s,e)=>Tick();timer.Start();Shown+=(s,e)=>{
            if(preview){Native.ShowWindow(Handle,5);BeginInvoke(new Action(()=>{Tick();using(var b=new Bitmap(Width,Height)){DrawToBitmap(b,new Rectangle(0,0,Width,Height));b.Save(Path.Combine(root,"app-preview.png"));}tabs.SelectedIndex=1;using(var b=new Bitmap(Width,Height)){DrawToBitmap(b,new Rectangle(0,0,Width,Height));b.Save(Path.Combine(root,"recording-preview.png"));}ShowCompact();compactState.Text="REKTFLIX  |  INTERFACE PREVIEW — recorder off";using(var b=new Bitmap(compact.Width,compact.Height)){compact.DrawToBitmap(b,new Rectangle(0,0,compact.Width,compact.Height));b.Save(Path.Combine(root,"compact-preview.png"));}compact.Close();closeAllowed=true;Close();}));}
            else {if(!string.IsNullOrEmpty(settings.WowFolder)){try{Wow.Install(settings.WowFolder);uiNote="Addon installed / up to date. Restart WoW if this is its first installation.";}catch(Exception ex){uiNote="Addon installation needs attention: "+ex.Message;}}}
        };
    }
    string Format(int seconds){return seconds%3600==0?(seconds/3600)+"h":seconds%60==0?(seconds/60)+"m":seconds+"s";}
    void Style(Button b){b.FlatStyle=FlatStyle.Flat;b.FlatAppearance.BorderColor=Color.FromArgb(70,72,86);b.BackColor=Color.FromArgb(42,43,55);b.ForeColor=Color.White;b.Font=new Font("Segoe UI",9,FontStyle.Bold);b.Size=new Size(138,34);b.Margin=new Padding(4);}
    Button Button(string text,Action click){var b=new Button{Text=text};Style(b);b.Click+=(s,e)=>{try{click();}catch(Exception ex){uiNote=ex.Message;Disk.Log(root,ex.ToString());MessageBox.Show(ex.Message,"Rektflix",MessageBoxButtons.OK,MessageBoxIcon.Warning);}};return b;}
    Button RainbowButton(string text,Action click){var b=new RainbowTextButton{Text=text};Style(b);b.Click+=(s,e)=>{try{click();}catch(Exception ex){uiNote=ex.Message;Disk.Log(root,ex.ToString());MessageBox.Show(ex.Message,"Rektflix",MessageBoxButtons.OK,MessageBoxIcon.Warning);}};return b;}
    TabPage Page(TabControl tabs,string name){var p=new TabPage(name){BackColor=background,ForeColor=Color.White,AutoScroll=true};tabs.TabPages.Add(p);return p;}
    void AddText(Control p,string text,int x,int y,int w,int h){p.Controls.Add(new Label{Text=text,Location=new Point(x,y),Size=new Size(w,h),ForeColor=muted});}
    void Number(Control p,string key,string label,int min,int max,ref int y){AddText(p,label,20,y+5,540,25);var n=new NumericUpDown{Minimum=min,Maximum=max,Value=(int)typeof(Settings).GetProperty(key).GetValue(settings,null),Location=new Point(600,y),Size=new Size(170,28),BackColor=card,ForeColor=Color.White};inputs[key]=n;p.Controls.Add(n);y+=40;}
    void Minutes(Control p,string key,string label,int min,int max,ref int y){AddText(p,label,20,y+5,540,25);int value=Math.Max(min,Math.Min(max,(int)typeof(Settings).GetProperty(key).GetValue(settings,null)/60));var n=new NumericUpDown{Minimum=min,Maximum=max,Value=value,Location=new Point(600,y),Size=new Size(170,28),BackColor=card,ForeColor=Color.White,Tag="minutes"};inputs[key]=n;p.Controls.Add(n);y+=40;}
    void Check(Control p,string key,string label,ref int y){var c=new CheckBox{Text=label,Checked=(bool)typeof(Settings).GetProperty(key).GetValue(settings,null),Location=new Point(20,y),Size=new Size(780,32)};inputs[key]=c;p.Controls.Add(c);y+=36;}
    void TextField(Control p,string key,string label,ref int y){AddText(p,label,20,y,790,25);y+=27;var t=new TextBox{Text=(string)typeof(Settings).GetProperty(key).GetValue(settings,null),Location=new Point(20,y),Size=new Size(790,28),BackColor=card,ForeColor=Color.White};inputs[key]=t;p.Controls.Add(t);y+=45;}
    void Apply(){foreach(var entry in inputs){var p=typeof(Settings).GetProperty(entry.Key);object value=entry.Value is NumericUpDown?(object)((int)((NumericUpDown)entry.Value).Value*((string)((NumericUpDown)entry.Value).Tag=="minutes"?60:1)):entry.Value is CheckBox?(object)((CheckBox)entry.Value).Checked:entry.Value.Text;p.SetValue(settings,value,null);}settings.Validate();Disk.Json(Path.Combine(root,"settings.json"),settings);StopWorker();failures=0;uiNote="Settings saved. Capture restarts when armed. In-game Apply & Reload can replace these values.";RefreshInputs();}
    void RefreshInputs(){foreach(var pair in inputs){object v=typeof(Settings).GetProperty(pair.Key).GetValue(settings,null);if(pair.Value is NumericUpDown){var n=(NumericUpDown)pair.Value;decimal value=(int)v/((string)n.Tag=="minutes"?60:1);n.Value=Math.Max(n.Minimum,Math.Min(n.Maximum,value));}else if(pair.Value is CheckBox)((CheckBox)pair.Value).Checked=(bool)v;else pair.Value.Text=(string)v;}RefreshQuickButtons();}
    void RefreshQuickButtons(){quickButtons.RemoveAll(b=>b.IsDisposed);foreach(var b in quickButtons){int n=(int)b.Tag;b.Text="Save "+Format(n==1?settings.QuickOne:n==2?settings.QuickTwo:settings.QuickThree);}}
    void InstallAddon(){settings.WowFolder=inputs["WowFolder"].Text;Disk.Json(Path.Combine(root,"settings.json"),settings);try{Wow.Install(settings.WowFolder);uiNote="Addon installed. Restart WoW after a first install. /rf opens the controls.";}catch(UnauthorizedAccessException){Process.Start(new ProcessStartInfo(Program.Exe,"--install-addon "+Program.Quote(settings.WowFolder)){UseShellExecute=true,Verb="runas"});uiNote="Windows is requesting permission to install the addon.";}}
    void ShowFreeSpace(){using(var f=new SpaceForm(root))f.ShowDialog(this);settings.FreeSpaceSetupSeen=true;Disk.Json(Path.Combine(root,"settings.json"),settings);}
    void OpenFolder(string folder){Directory.CreateDirectory(folder);Process.Start(new ProcessStartInfo(folder){UseShellExecute=true});}
    void Restore(){Show();WindowState=FormWindowState.Normal;Activate();}
    void ShowHelp(){string lua=File.ReadAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Addon","Rektflix","Rektflix.lua"));int start=lua.IndexOf("local helpText = [[",StringComparison.Ordinal)+18;int end=lua.IndexOf("]]",start,StringComparison.Ordinal);var f=new Form{Text="Rektflix — Help manual",Size=new Size(820,680),StartPosition=FormStartPosition.CenterParent,BackColor=background};f.Controls.Add(new RichTextBox{Dock=DockStyle.Fill,ReadOnly=true,Text=lua.Substring(start,end-start),BackColor=background,ForeColor=Color.White,Font=new Font("Segoe UI",11),BorderStyle=BorderStyle.None,WordWrap=true});f.Show(this);}
    void ShowCompact(){if(compact!=null&&!compact.IsDisposed){compact.Show();return;}compact=new Form{Text="Rektflix",ClientSize=new Size(650,88),FormBorderStyle=FormBorderStyle.FixedToolWindow,TopMost=true,BackColor=background,StartPosition=FormStartPosition.Manual,Location=new Point(40,40)};
        compactState=new Label{Text="REKTFLIX",ForeColor=accent,Location=new Point(10,8),Size=new Size(625,25),Font=new Font("Segoe UI",11,FontStyle.Bold)};compact.Controls.Add(compactState);
        for(int n=1;n<=5;n++){int code=n;var b=Button(n<=3?"Save "+Format(n==1?settings.QuickOne:n==2?settings.QuickTwo:settings.QuickThree):n==4?"● Record":"■ Stop clip",()=>Command(code));if(n<=3){b.Tag=n;quickButtons.Add(b);}b.SetBounds(8+(n-1)*128,43,122,32);compact.Controls.Add(b);}compact.Show();}
    void Command(int code){if(worker==null||worker.HasExited){uiNote="Recorder is not running. Arm it and wait for video capture first.";return;}Disk.Atomic(Path.Combine(root,"save-"+Guid.NewGuid().ToString("N")+".request"),System.Text.Encoding.ASCII.GetBytes(code.ToString()));uiNote="Clip request queued.";}
    void StopWorker(){if(worker!=null&&!worker.HasExited&&stoppedAt==0){Disk.Atomic(Path.Combine(root,"stop.request"),new byte[]{1});stoppedAt=Disk.Now;}}
    void Quit(){quitting=true;armed=false;StopWorker();if(worker==null||worker.HasExited){closeAllowed=true;timer.Stop();tray.Visible=false;tray.Dispose();if(compact!=null)compact.Close();Close();}}
    void Tick(){try{
        arm.Text=armed?"Disarm":"Arm recorder";banner.Text=uiNote;
        if(worker!=null&&worker.HasExited){int code=worker.ExitCode;worker.Dispose();worker=null;stoppedAt=0;if(code!=0){failures++;nextLaunch=Disk.Now+5;if(settings.HardwareEncoder&&failures==1){settings.HardwareEncoder=false;Disk.Json(Path.Combine(root,"settings.json"),settings);RefreshInputs();uiNote="Capture failed. Retrying with Windows software encoding; see diagnostics.";}if(failures>=3){armed=false;uiNote="Capture failed repeatedly. Recording is OFF. Open diagnostics for details.";}}}
        if(worker!=null&&stoppedAt>0&&Disk.Now-stoppedAt>20){worker.Kill();uiNote="Recorder did not stop in time. Completed fragments will recover on restart.";}
        if(quitting){Quit();return;}
        if(!preview&&Disk.Now-importedAt>5){importedAt=Disk.Now;ImportAddon();}
        if(worker==null&&armed&&Disk.Now>=nextLaunch&&!preview){using(var wow=Wow.Find(settings.WowFolder))if(wow!=null){foreach(string p in Directory.GetFiles(root,"save-*.request"))File.Delete(p);string stop=Path.Combine(root,"stop.request");if(File.Exists(stop))File.Delete(stop);string oldState=Path.Combine(root,"state.json");if(File.Exists(oldState))File.Delete(oldState);
            worker=Process.Start(new ProcessStartInfo(Program.Exe,"--worker "+Program.Quote(root)+" "+wow.MainWindowHandle.ToInt64()+" "+Process.GetCurrentProcess().Id){UseShellExecute=false,CreateNoWindow=true});launchedAt=Disk.Now;nextLaunch=Disk.Now+5;}}
        WorkerState ws=null;try{if(File.Exists(Path.Combine(root,"state.json")))ws=Disk.Read<WorkerState>(Path.Combine(root,"state.json"));}catch{}
        bool live=worker!=null&&!worker.HasExited;state.Text=live&&stoppedAt>0?"STOPPING CAPTURE":!armed?"DISARMED — recording off":!live?"WAITING FOR WOW":ws!=null&&ws.Error!=null?"CAPTURE ERROR":ws!=null&&ws.LastFragment>0?"● BUFFER RECORDING":"STARTING CAPTURE";state.Font=state.Text=="WAITING FOR WOW"?stateWaitingFont:stateNormalFont;
        state.ForeColor=live&&ws!=null&&ws.LastFragment>0&&ws.Error==null?Color.FromArgb(105,224,159):Color.FromArgb(245,187,93);
        detail.Text=live&&ws!=null?string.Format("Buffer: {0:0}s / {1}s    •    Pending clips: {2}    •    {3}\n{4}",ws.BufferSeconds,settings.BufferSeconds,ws.PendingClips,ws.ManualRecording?"Manual recording ON":"Manual recording off",ws.CombatLines>0?"Combat-log lines received: "+ws.CombatLines:"No fresh combat-log events yet. Automatic triggers are not verified."):"Open WoW with this app armed. /rf or /rektflix opens the addon settings.";
        if(live&&ws!=null&&Disk.Now-ws.Heartbeat>30){StopWorker();uiNote="Recorder heartbeat stalled; requesting recovery restart.";}
        if(live&&ws==null&&Disk.Now-launchedAt>90){StopWorker();uiNote="Recorder startup stalled; requesting recovery restart.";}
        if(compactState!=null&&!compactState.IsDisposed)compactState.Text="REKTFLIX  |  "+state.Text;
    }catch(Exception ex){uiNote=ex.Message;Disk.Log(root,ex.ToString());}}
    void ImportAddon(){string accounts=Path.Combine(settings.WowFolder,"WTF","Account");if(!Directory.Exists(accounts))return;
        string p=Directory.GetDirectories(accounts).Select(x=>Path.Combine(x,"SavedVariables","Rektflix.lua")).Where(File.Exists).OrderByDescending(File.GetLastWriteTimeUtc).FirstOrDefault();
        if(p!=null&&AddonSettings.Import(File.ReadAllText(p),settings)){Disk.Json(Path.Combine(root,"settings.json"),settings);RefreshInputs();StopWorker();uiNote="Imported addon settings. Restarting capture safely.";}
    }
}
}
