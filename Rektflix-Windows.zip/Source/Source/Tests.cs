using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Text;
using System.Threading;
using System.Diagnostics;
using System.Collections.Generic;
namespace ForeverRecorder {
public static class Tests {
    static int passed;static List<string> report;
    static void Check(bool ok,string title){if(!ok)throw new Exception("FAIL: "+title);passed++;report.Add("PASS: "+title);}
    public static int Run(string root){Directory.CreateDirectory(root);report=new List<string>();passed=0;
        try{
            Check(new Settings().BufferLimitGB==15,"New installs default to a 15 GB maximum buffer");
            var s=new Settings{BufferSeconds=30,BeforeSeconds=300,QuickThree=120,ClipsFolder=Path.Combine(root,"clips")};s.Validate();Check(s.BeforeSeconds==30&&s.QuickThree==30,"Durations are clamped to available buffer");
            var fiveHour=new Settings{BufferSeconds=99999,BeforeSeconds=99999,QuickThree=99999};fiveHour.Validate();Check(fiveHour.BufferSeconds==18000&&fiveHour.BeforeSeconds==18000&&fiveHour.QuickThree==18000,"Five-hour buffer and save limits");
            var p=new CombatParser(s);string prefix="10/14 12:00:00.000  ";
            string kill="PARTY_KILL,Player-1-SELF,\"Me\",0x511,0x0,Player-1-OTHER,\"Enemy, quoted\",0x548,0x0";
            var t=p.Parse(prefix+kill,100);Check(t!=null&&t.Kind=="My PvP kill"&&t.Victim=="Enemy, quoted","Player killing blow / quoted CSV names");
            Check(p.Parse(prefix+kill,101)==null,"Duplicate kill suppression");
            Check(p.Parse(prefix+kill.Replace("Player-1-OTHER","Creature-1-OTHER"),105)==null,"PvE deaths do not trigger default PvP rule");
            Check(p.Parse(prefix+kill.Replace("0x511","0x512"),110)==null,"Party kill excluded by default");
            Check(p.Parse(prefix+kill.Replace("0x548","0x518"),115)==null,"Friendly player death excluded from PvP kills");
            s.PartyPvpKills=true;Check(new CombatParser(s).Parse(prefix+kill.Replace("0x511","0x512"),120)!=null,"Party PvP kill option");
            Check(p.Parse(prefix+"UNIT_DIED,0000000000000000,nil,0x80000000,0x0,Player-1-SELF,Me,0x511,0x0",130)?.Kind=="My death","Own death identification");
            Check(p.Parse("garbage and broken CSV",140)==null,"Malformed log ignored");
            var csv=CombatParser.Csv("SPELL_CAST_SUCCESS,\"Name \"\"quoted\"\"\",x");Check(csv[1]=="Name \"quoted\"","Escaped CSV quotes");
            s.SpellIds="123,456";Check(new CombatParser(s).Parse(prefix+"SPELL_CAST_SUCCESS,Player-1-SELF,Me,0x511,0,Player-2,T,0x548,0,123,Spell,1",150)==null,"Spell ID trigger remains off until enabled");s.SpellCasts=true;Check(new CombatParser(s).Parse(prefix+"SPELL_CAST_SUCCESS,Player-1-SELF,Me,0x511,0,Player-2,T,0x548,0,123,Spell,1",150)?.Kind=="Spell 123","Selected spell ID trigger");
            s.LootChatLogging=true;s.LootIds="19019";Check(p.ParseLoot("Loot |Hitem:19019:0:0|h[Item]|h",151)!=null,"Watched item link trigger");
            Check(p.ParseLoot("Loot |Hitem:19018:0:0|h[Item]|h",152)==null,"Other item ignored");
            string flat="RektflixDB = { [\"revision\"] = \"42\", [\"bufferSeconds\"] = 120, [\"fps\"] = 60, [\"quickOne\"] = 45, [\"microphone\"] = true, [\"spellCasts\"] = true }";
            Check(AddonSettings.Import(flat,s)&&s.Fps==60&&s.Microphone&&s.QuickOne==45&&s.SpellCasts,"Addon scalar and spell-trigger toggle settings import");Check(!AddonSettings.Import(flat,s),"Same addon revision does not overwrite Windows changes repeatedly");
            string logDir=Path.Combine(root,"logs");Directory.CreateDirectory(logDir);string log=Path.Combine(logDir,"WoWCombatLog.txt");File.WriteAllText(log,"historical\n");
            using(var tail=new LogTail()){Check(!tail.Poll(logDir,"WoWCombatLog*.txt").Any(),"Existing log starts at EOF");File.AppendAllText(log,"partial");Check(!tail.Poll(logDir,"WoWCombatLog*.txt").Any(),"Incomplete line retained");File.AppendAllText(log," complete\n");Check(tail.Poll(logDir,"WoWCombatLog*.txt").Single()=="partial complete","Partial line completed exactly once");File.WriteAllText(log,"x\n");Check(tail.Poll(logDir,"WoWCombatLog*.txt").Single()=="x","Log truncation recovered");}
            using(var b=new Bitmap(112,8)){using(var g=Graphics.FromImage(b)){g.Clear(Color.Black);g.FillRectangle(new SolidBrush(Color.FromArgb(255,0,128)),0,0,4,8);g.FillRectangle(new SolidBrush(Color.FromArgb(0,255,128)),4,0,4,8);int code=3,seq=27,arg=0;int packed=code+(seq<<4)+(arg<<12)+(((code+seq+arg)%16)<<20);for(int i=0;i<24;i++)if((packed&(1<<i))!=0)g.FillRectangle(Brushes.White,(i+2)*4,0,4,8);Check((SignalBridge.Decode(b)&15)==3,"In-game control strip decoded / checksum validated");g.FillRectangle(Brushes.Red,20,0,4,8);Check(SignalBridge.Decode(b)==-1,"Corrupted signal rejected");}}
            string forever=Path.Combine(root,"_classic_beta_");Directory.CreateDirectory(forever);File.WriteAllBytes(Path.Combine(forever,"WowB.exe"),new byte[]{1});Check(Wow.Executable(forever).EndsWith("WowB.exe"),"Forever WowB executable and _classic_beta_ layout recognized");
            Wow.Install(forever);string installed=Path.Combine(forever,"Interface","AddOns","Rektflix");Check(File.Exists(Path.Combine(installed,"Rektflix_Camelot.toc"))&&File.Exists(Path.Combine(installed,"Rektflix.lua")),"Simulated addon install into fake _classic_beta_ with WowB.exe");
            SpaceTests.Run(Path.Combine(root,"space"),Check,report);
            Disk.Json(Path.Combine(root,"settings.json"),new Settings{Width=640,Height=360,Fps=30,BitrateMbps=3,BufferSeconds=15,BeforeSeconds=3,AfterSeconds=2,SystemAudio=false,HardwareEncoder=false,MinimumFreeGB=1,ClipsFolder=Path.Combine(root,"clips")});
            report.Add("START: Native Media Foundation synthetic recording integration test");File.WriteAllLines(Path.Combine(root,"test-report.txt"),report);
            int result=Engine.Run(root,0,0,"synthetic",10);Check(result==0,"Native encoder / fragment stream / clip export / clean stop");
            Check(Directory.GetFiles(Path.Combine(root,"clips"),"*.mp4").Any(),"Integration produced a saved MP4 clip");
            string folder=Directory.GetDirectories(Path.Combine(root,"buffer"),"session-*").Last();var meta=Disk.Read<SessionInfo>(Path.Combine(folder,"session.json"));meta.Clean=false;Disk.Json(Path.Combine(folder,"session.json"),meta);
            int recovered=BufferStore.Recover(Path.Combine(root,"buffer"),Disk.Read<Settings>(Path.Combine(root,"settings.json")));Check(recovered>0,"Interrupted session buffer recovered to clip");Check(BufferStore.Recover(Path.Combine(root,"buffer"),Disk.Read<Settings>(Path.Combine(root,"settings.json")))==0,"Recovery idempotence");
            report.Add("TOTAL: "+passed+" passed. Live Forever gameplay NOT tested.");File.WriteAllLines(Path.Combine(root,"test-report.txt"),report);return 0;
        }catch(Exception ex){report.Add(ex.ToString());File.WriteAllLines(Path.Combine(root,"test-report.txt"),report);return 1;}
    }
}
}
