@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cd /d "%~dp0"
if not exist ".build" mkdir ".build"
cl /nologo /std:c++20 /EHsc /O2 /MD /LD /DWIN32_LEAN_AND_MEAN NativeRecorder.cpp /Fe:..\Rektflix.Native.dll /Fo:.build\NativeRecorder.obj /link d3d11.lib dxgi.lib windowsapp.lib mf.lib mfplat.lib mfreadwrite.lib mfuuid.lib ole32.lib oleaut32.lib uuid.lib user32.lib gdi32.lib runtimeobject.lib /IMPLIB:.build\Rektflix.Native.lib
exit /b %errorlevel%
