$ErrorActionPreference = 'Stop'
$projectDir = $PSScriptRoot
$packageDir = Split-Path $projectDir
$compiler = 'C:/Program Files (x86)/Microsoft Visual Studio/18/BuildTools/MSBuild/Current/Bin/Roslyn/csc.exe'
if (!(Test-Path $compiler)) { throw 'Install Visual Studio Build Tools with the .NET Framework desktop build tools, then update the compiler path in build.ps1.' }
& "$projectDir/build-native.cmd"
if ($LASTEXITCODE -ne 0) { throw 'Native compilation failed' }
$sources = Get-ChildItem "$projectDir/*.cs" | ForEach-Object FullName
& $compiler /nologo /target:winexe /platform:x64 /langversion:latest /optimize+ "/win32manifest:$projectDir/App.manifest" "/win32icon:$projectDir/Assets/rektflix-red-r.ico" "/resource:$projectDir/Assets/rektflix-red-r.ico,Rektflix.AppIcon.ico" "/resource:$projectDir/Assets/emoji-cupcake-3d-96.png,Rektflix.EmojiCupcake.png" "/resource:$projectDir/Assets/emoji-cosmos-3d-96.png,Rektflix.EmojiCosmos.png" "/out:$packageDir/Rektflix.exe" /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Web.Extensions.dll $sources
if ($LASTEXITCODE -ne 0) { throw 'Compilation failed' }
$crt = 'C:/Program Files (x86)/Microsoft Visual Studio/18/BuildTools/VC/Redist/MSVC/14.51.36231/x64/Microsoft.VC145.CRT'
if (Test-Path $crt) { Copy-Item "$crt/*.dll" $packageDir -Force }
Write-Output "Built $packageDir/Rektflix.exe"
